-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 16, 2020 at 12:21 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `paipixel`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `role` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `user_name` text NOT NULL,
  `phone_number` varchar(16) NOT NULL,
  `email` varchar(250) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `back_data` varchar(250) NOT NULL,
  `class` text NOT NULL,
  `school` text NOT NULL,
  `Address` text NOT NULL,
  `google_location` text NOT NULL,
  `show_location` int(11) NOT NULL,
  `interested` text NOT NULL,
  `bio` text NOT NULL,
  `image` text NOT NULL,
  `rating` int(110) NOT NULL,
  `friend` longtext NOT NULL,
  `balance` int(11) NOT NULL,
  `active` datetime NOT NULL,
  `deactive` int(11) NOT NULL,
  `background` text NOT NULL,
  `phone_confirm` int(11) NOT NULL,
  `email_confirm` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `role`, `datetime`, `user_name`, `phone_number`, `email`, `first_name`, `last_name`, `back_data`, `class`, `school`, `Address`, `google_location`, `show_location`, `interested`, `bio`, `image`, `rating`, `friend`, `balance`, `active`, `deactive`, `background`, `phone_confirm`, `email_confirm`) VALUES
(5, 1, '2020-07-14 13:49:18', 'supto', '01834758140', '', 'supto', 'kumar', '0cc175b9c0f1b6a831c399e269772661', '0', 'mps', 'barite thaki', 'nai', 0, '', 'Amar bio', '', 0, 'supto', 0, '0000-00-00 00:00:00', 0, '', 0, 0),
(6, 1, '2020-07-15 11:17:18', 'supto.54', '01834758140', '', 'somojit', 'kumar', '0cc175b9c0f1b6a831c399e269772661', '0', 'ana', '', '', 0, '', '', '', 0, 'supto.54', 0, '0000-00-00 00:00:00', 0, '', 0, 0),
(7, 1, '2020-07-15 18:40:53', 'alim', '01434567891', 'a@a.com', 'Alim', 'Ahmed', '0cc175b9c0f1b6a831c399e269772661', '0', 'son', '', '', 0, '', 'dsfdas etes', '', 0, 'alim', 0, '0000-00-00 00:00:00', 0, '', 0, 0),
(8, 2, '2020-07-15 19:16:12', 'kumar', '01478523691', '', 'baba', 'ami', 'c4ca4238a0b923820dcc509a6f75849b', 'intermediate', '', '', '', 0, '', '', 'image/user.PNG', 0, 'kumar', 0, '0000-00-00 00:00:00', 0, '', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
