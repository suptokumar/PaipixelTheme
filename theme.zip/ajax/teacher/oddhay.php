<?php 
$class = $_GET['class'];
$subject = $_GET['subject'];
?>
<?php 
	if ($subject=='') {
		?>
<option value="">-- SELECT --</option>

		<?php
	}
if ($class==6) { 
if ($subject=='বাংলা প্রথম পত্র') {
?>
<option value="">-- SELECT --</option>
<optgroup label="গদ্য">
<option value="অধ্যায়-১: সততার পুরস্কার "> অধ্যায়-১: সততার পুরস্কার </option>
<option value="অধ্যায়-২: মিনু"> অধ্যায়-২: মিনু </option>

<option value="অধ্যায়-৩: নীলনদ আর পিরামিডের দেশ"> অধ্যায়-৩: নীলনদ আর পিরামিডের দেশ </option>

<option value="অধ্যায়-৪: তোলপাড়"> অধ্যায়-৪: তোলপাড় </option>

<option value="অধ্যায়-৫: অমর একুশে"> অধ্যায়-৫: অমর একুশে </option>

<option value="অধ্যায়-৬: অকাশ"> অধ্যায়-৬:আকাশ </option>

<option value="অধ্যায়-৭: মাদার তেরেসা"> অধ্যায়-৭: মাদার তেরেসা </option> 

<option value="অধ্যায়-৮: কতদিকে কত কারিগর"> অধ্যায়-৮: কতদিকে কত কারিগর </option>

<option value="অধ্যায়-৯: কতকাল ধরে"> অধ্যায়-৯: কতকাল ধরে </option>

</optgroup>



<optgroup label="কবিতা">
<option value="অধ্যায়-১: জন্মভূমি"> অধ্যায়-১: জন্মভূমি </option>

<option value="অধ্যায়-২: সুখ"> অধ্যায়-২: সুখ </option>

<option value="অধ্যায়-৩: মানুষ জাতি">  অধ্যায়-৩: মানুষ জাতি </option>

<option value="অধ্যায়-৪: ঝিঙে ফুল"> অধ্যায়-৪: ঝিঙে ফুল </option>

<option value="অধ্যায়-৫: আসমানি"> অধ্যায়-১৪: আসমানি </option>

<option value="অধ্যায়-৬: মুজিব"> অধ্যায়-৬: মুজিব </option>

<option value="অধ্যায়-৭: বাঁচতে দাও"> অধ্যায়-৭: বাঁচতে দাও </option>

<option value="অধ্যায়-৮: পাখির কাছে ফুলের কাছে"> অধ্যায়-৮: পাখির কাছে ফুলের কাছে </option>

<option value="অধ্যায়-৯: ফাগুন মাস"> অধ্যায়-৯: ফাগুন মাস </option>

</optgroup>

<optgroup label="আনন্দপাঠ">
<option value="অধ্যায়-১:আয়না"> অধ্যায়-১:আয়না </option>

<option value="অধ্যায়-২:জাদুক"> অধ্যায়-২:জাদুকর </option>

<option value="অধ্যায়-৩:ঋণ পরিশােধ"> অধ্যায়-৩:ঋণ পরিশােধ </option>

<option value="অধ্যায়-৪:রাখালের বুদ্ধি (ভিনদেশি রূপকথা)"> অধ্যায়-৪:রাখালের বুদ্ধি (ভিনদেশি রূপকথা) </option>

<option value="অধ্যায়-৫:বালকের সততা"> অধ্যায়-৫:বালকের সততা </option>

<option value="অধ্যায়-৬:কাঠের পা"> অধ্যায়-৬:কাঠের পা </option>

<option value="অধ্যায়- ৭:চিন্তাশীল (নাটিকা)"> অধ্যায়- ৭:চিন্তাশীল (নাটিকা) </option>

<option value="অধ্যায়-৮:অমি ও আইসক্রিমঅলা"> অধ্যায়-৮:অমি ও আইসক্রিম’অলা </option>

<option value="অধ্যায়-৯:রসুলের দেশে (ভ্রমণকাহিনি)"> অধ্যায়-৯:রসুলের দেশে (ভ্রমণকাহিনি) </option>

<option value="অধ্যায়-১০:ওকিং মসজিদে ঈদের জামায়াত (ভ্রমণকাহিনি)"> অধ্যায়-১০:ওকিং মসজিদে ঈদের জামায়াত (ভ্রমণকাহিনি) </option>

</optgroup>

		<?php
	}
if ($subject=='বাংলা দ্বিতীয় পত্র') {
		?>
<option value="">-- SELECT --</option>
<optgroup label="ব্যাকরণ">
<option value="অধ্যায়-১: ভাষা ও বাংলা ভাষা"> অধ্যায়-১: ভাষা ও বাংলা ভাষা </option>
<option value="অধ্যায়-২:ধ্বনিতত্ত্ব"> অধ্যায়-১:ধ্বনিতত্ত্ব </option>
<option value="অধ্যায়-৩: রুপতত্ত্ব">অধ্যায়-২: রুপতত্ত্ব </option>
<option value="অধ্যায়-৪: বাক্যতত্ত্ব">অধ্যায়-৩: বাক্যতত্ত্ব </option>
<option value="অধ্যায়-৫: বাগর্থ ">অধ্যায়-:৫ বাগর্থ </option>
<option value="অধ্যায়-৬: বানান">অধ্যায়-৬: বানান </option>
<option value="অধ্যায়-৭: বিরামচিহ্ন">অধ্যায়-৭: বিরামচিহ্ন </option>
<option value="অধ্যায়-৮: অভিদান">অধ্যায়-৮: অভিধান </option>

</optgroup>
<optgroup label="নির্মিতি">
<option value="অধ্যায়-১: অনুধাবন">অধ্যায়-১: অনুধাবন </option>
<option value="অধ্যায়-২: সারাংশ ও সারমর্ম রচনা"> অধ্যায়-২: সারাংশ ও সারমর্ম রচনা </option>
<option value="অধ্যায়-৩: ভাব সম্প্রসারণ"> অধ্যায়-৩: ভাব সম্প্রসারণ </option>
<option value="অধ্যায়-৪: পত্র রচন"> অধ্যায়-৪: পত্র রচনা  </option> 
<option value="অধ্যায়-৫: অনুচ্ছেদ রচনা"> অধ্যায়-৫: অনুচ্ছেদ রচনা </option>
<option value="অধ্যায়-৬: প্রবন্ধ রচনা"> অধ্যায়-৬: প্রবন্ধ রচনা </option>
</optgroup>
		<?php
	}
if ($subject=='ইংরেজি প্রথম পত্র') {
		?>
<option value="">-- SELECT --</option>
<option value="Lesson-1: Going to a new school">Lesson-1: Going to a new school </option>
<option value=" Lesson-2: Congratulations! Well done!">Lesson-2: Congratulations! Well done! </option>
<option value=" Lesson-3: A railway station">Lesson-3: A railway station </option>
<option value=" Lesson-4: Where are you from?">Lesson-4: Where are you from? </option>
<option value="Lesson-5: Thanks for your work">Lesson-5: Thanks for your work </option>
<option value="Lesson-5: It smells good!!">Lesson-7: It smells good! </option>
<option value="Lesson-7: Holding Hands">Lesson-7: Holding Hands </option>
<option value="Lesson-8: Grocery shopping">Lesson-8: Grocery shopping </option>
<option value="Lesson-9: Health is wealth">Lesson-9: Health is wealth </option>
<option value="Lesson- 10: Remedies: modern and traditional">Lesson-10: Remedies: modern and traditional </option>
<option value="Lesson-11: Are you listening?-1">Lesson-11: Are you listening?-1 </option>
<option value="Lesson-12: Birds of Bangladesh">Lesson-12: Birds of Bangladesh </option>
<option value="Lesson-13: An unseen beauty of Bangladesh">Lesson-13: An unseen beauty of Bangladesh </option>
<option value="Lesson-14: Our pride">Lesson-14: Our pride </option> 
<option value="Lesson-15: The lion's mane">Lesson-15: The lion's mane </option>
<option value="Lesson-16: An old people's home">Lesson-16: An old people's home</option>
<option value="Lesson-17: Boats sail on the rivers">Lesson-17: Boats sail on the rivers </option>
<option value="Lesson-18: Are you listening?-2">Lesson-18: Are you listening?-2</option>
<option value="Lesson-19: Make your snacks">Lesson-19: Make your Snacks </option>
<option value="Lesson-20: Stop, look and listen">Lesson-20: Stop, look and listen </option>
<option value="Lesson- 21: Hason Raja: the mystic bard of Bangladesh">Lesson-21:  Hason Raja: the mystic bard of Bangladesh </option>
<option value="Lesson-22:Wonders of the world-1">Lesson-22: Wonders of the world-1 </option>
<option value="Lesson-23: Wonders of the world-2">Lesson-23: Wonders of the world-2 </option>
<option value="Lesson-24: Aesop's fable">Lesson-24: Aesop's fable</option>
<option value="Lesson-25: We live in a global village">Lesson-25: We live in a global village</option>
<option value="Lesson-26: Our wage earners">Lesson-26: Our wage earners</option>
<option value="Lesson- 27: The concert for Bangladesh">Lesson-27: The concert for Bangladesh </option>
<option value="Lesson- 28: Buying clothes">Lesson-28: Buying clothes </option>
<option value="Lesson-29: Andre">Lesson-29: Andre </option>
<option value="Lesson-30: Are you listening?-3">Lesson-30: Are you listening?-3 </option> 
<option value="Lesson-31: Taking a test">Lesson-31: Tasking a test </option>
<option value="Lesson-32: What should we do?"> esson-32' What should we do?">
<option value="Lesson-33: Too much or too little water">Lesson-33: Too much or too little water </option>
<option value="Lesson-34: An invitation for Robin">Lesson-34: An invitation for Robin </option>
<option value="Lesson-35: The Garden"> Lesson-35: The Garden</option>

		<?php
	}



if ($subject=='ইংরেজি দ্বিতীয় পত্র') {
		?>
<option value="">-- SELECT --</option>
<optgroup label="Grammar">
<option value="Unit-01:Parts of Speech">Unit-01:Parts of Speech </option>
<option value="Unit-02:The Tenses">Unit-2: The Tenses </option>
<option value="Unit-03:Articles: a, an, the">Unit-03: Articles: a, an, the  </option>
<option value="Unit-04:Possessives">Unit-04: Possessives </option>
<option value="Unit-05:The-ing form of Verb - Gerund and Participle">Unit-05: The-ing form of Verb - Gerund and Participle </option>
<option value="Unit-06:Sentences">Unit-06: Sentences </option>
<option value="Unit-07:Introductory 'There' and 'It' ">Unit-07: Introductory 'There' and 'It' </option>
<option value="Unit-08:Punctuation and Capitalisation">Unit-08: Punctuation and Capitalisation </option>
</optgroup>
<optgroup label="Composition">
<option value="Unit-09:Letters and E-mails">Unit-09: Letters and E-mails </option>
<option value="Unit-10:Writing Paragraphs">Unit-10: Writing Paragraphs </option>
</optgroup>
		<?php
	}





if ($subject=='গনিত') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১: স্বাভাবিক সংখ্যা ও ভগ্নাংশ"> অধ্যায়-১: স্বাভাবিক সংখ্যা ও ভগ্নাংশ </option>
<option value="অধ্যায়-২: অনুপাত ও শতকরা"> অধ্যায়-২: অনুপাত ও শতকরা </option>
<option value="অধ্যায়-৩: পূর্ণসংখ্যা"> অধ্যায়-৩: পূর্ণসংখ্যা </option>
<option value="অধ্যায়-৪: বীজগণিতীয় রাশি"> অধ্যায়-৪: বীজগণিতীয় রাশি </option>
<option value="অধ্যায়-৫: সরল সমীকরণ"> অধ্যায়-৫: সরল সমীকরণ  </option>
<option value="অধ্যায়-৬: জ্যামিতির মৌলিক ধারণা"> অধ্যায়-৬: জ্যামিতির মৌলিক ধারণা </option> 
<option value="অধ্যায়-৭: ব্যবহারিক জ্যামিতি">অধ্যায়-৭: ব্যবহারিক জ্যামিতি </option>
<option value="অধ্যায়-৮: তথ্য ও উপাত্ত"> অধ্যায়-৮: তথ্য ও উপাত্ত  </option>

		<?php
	}


	

if ($subject=='সাধারণ বিজ্ঞান') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:বৈজ্ঞানিক প্রক্রিয়া ও পরিমাপ"> অধ্যায়-১: বৈজ্ঞানিক প্রক্রিয়া ও পরিমাপ</option>
<option value="অধ্যায়-২: জীবজগৎ"> অধ্যায়-২: জীবজগৎ </option>
<option value="অধ্যায়-৩: উদ্ভিদ ও প্রাণীর কোষীয় সংগঠন"> অধ্যায়-৩: উদ্ভিদ ও প্রাণীর কোষীয় সংগঠন </option>
<option value="অধ্যায়-৪:উদ্ভিদের বাহ্যিক বৈশিষ্ট্য">  অধ্যায়-৪: উদ্ভিদের বাহ্যিক বৈশিষ্ট্য  </option>
<option value="অধ্যায়-৫:সালােকসংশ্লেষণ"> অধ্যায়-৫:সালােকসংশ্লেষণ </option>
<option value="অধ্যায়-৬:সংবেদি অঙ্গ"> অধ্যায়-৬:সংবেদি অঙ্গ </option>
<option value="অধ্যায়-৭:পদার্থের বৈশিষ্ট্য এবং বাহ্যিক প্রভাব">  অধ্যায়-৭:পদার্থের বৈশিষ্ট্য এবং বাহ্যিক প্রভাব </option>
<option value="অধ্যায়-৮:মিশ্রণ"> অধ্যায়-১:মিশ্রণ </option>
<option value="অধ্যায়-৯:আলাের ঘটনা"> অধ্যায়-৯:আলাের ঘটনা </option>
<option value="অধ্যায়-১০:গতি"> অধ্যায়-১০:গতি </option>
<option value="অধ্যায়-১১:বল এবং সরল যন্ত্র"> অধ্যায়-১১: বল এবং সরল যন্ত্র </option>
<option value="অধ্যায়-১২:পৃথিবীর উৎপত্তি ও গঠন"> অধ্যায়-১২:পৃথিবীর উৎপত্তি ও গঠন  </option>
<option value="অধ্যায়-১৩: খাদ্য ও পুষ্টি"> অধ্যায়-১৩: খাদ্য ও পুষ্টি </option>
<option value="অধ্যায়-১৪:পরিবেশের ভারসাম্য এবং আমাদের জীবন"> অধ্যায়-১৪:পরিবেশের ভারসাম্য এবং আমাদের জীবন </option>

		<?php
	}

	

if ($subject=='বাংলাদেশ ও বিশ্ব পরিচয়') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:বাংলাদেশের ইতিহাস">অধ্যায়-১:বাংলাদেশের ইতিহাস </option>
<option value="অধ্যায়-২:বাংলাদেশ ও বিশ্বসভ্যতা"> অধ্যায়-২:বাংলাদেশ ও বিশ্বসভ্যতা </option>
<option value="অধ্যায়-৩: বিশ্ব-ভৌগােলিক পরিমণ্ডলে বাংলাদেশ"> অধ্যায়-৩: বিশ্ব-ভৌগােলিক পরিমণ্ডলে বাংলাদেশ</option>
<option value="অধ্যায়-৪:বাংলাদেশের জনসংখ্যা পরিচিতি"> অধ্যায়-৪:বাংলাদেশের জনসংখ্যা পরিচিতি </option>
<option value="অধ্যায়-৪:বাংলাদেশের সমাজ">অধ্যায়-৫:বাংলাদেশের সমাজ </option>
<option value="অধ্যায়-৬:বাংলাদেশের সংস্কৃতি">অধ্যায়-৬:বাংলাদেশের সংস্কৃতি</option>
<option value="অধ্যায়-৭:বাংলাদেশের অর্থনীতি">অধ্যায়-৭:বাংলাদেশের অর্থনীতি</option>
<option value="অধ্যায়-৮:বাংলাদেশ ও বাংলাদেশের নাগরিক">অধ্যায়-৮:বাংলাদেশ ও বাংলাদেশের নাগরিক </option>
<option value="অধ্যায়-৯:বাংলাদেশের পরিবেশ">অধ্যায়-৯:বাংলাদেশের পরিবেশ </option>
<option value="অধ্যায়-১০:বাংলাদেশে শিশু অধিকার">অধ্যায়-১০:বাংলাদেশে শিশু অধিকার </option>
<option value="অধ্যায়-১১:বাংলাদেশে শিশুর বেড়ে ওঠা ও প্রতিবন্ধকতা">অধ্যায়-১১:বাংলাদেশে শিশুর বেড়ে ওঠা ও প্রতিবন্ধকতা</option>
<option value="অধ্যায়-১২:বাংলাদেশ ও আঞ্চলিক সহযােগিতা"> অধ্যায়-১২:বাংলাদেশ ও আঞ্চলিক সহযােগিতা </option>
<option value="অধ্যায়-১৩: টেকসই উন্নয়ন অভীষ্ট (এসডিজি)"> অধ্যায়-১৪: টেকসই উন্নয়ন অভীষ্ট (এসডিজি) </option>

		<?php
	}
	

if ($subject=='কৃষিশিক্ষা') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:আমাদের জীবনে কৃষি">অধ্যায়-১:আমাদের জীবনে কৃষি </option>
<option value="অধ্যায়-২:কৃষি প্রযুক্তি ও যন্ত্রপাতি">অধ্যায়-২:কৃষি প্রযুক্তি ও যন্ত্রপাতি </option>

<option value="অধ্যায়-৩:কৃষি উপকরণ"> অধ্যায়-৩:কৃষি উপকরণ </option>

<option value="অধ্যায়-৪:কৃষি ও জলবায়ু"> অধ্যায়-৪:কৃষি ও জলবায়ু </option>

<option value="অধ্যায়-৫:কৃষিজ উৎপাদন"> অধ্যায়-৫:কৃষিজ উৎপাদন </option>

<option value="অধ্যায়-৬:বনায়ন"> অধ্যায়-৬:বনায়ন </option>

		<?php
	}	









if ($subject=='তথ্য ও যোগাযোগ প্রযুক্তি') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:তথ্য ও যােগাযােগ প্রযুক্তি পরিচিতি"> অধ্যায়-১:তথ্য ও যােগাযােগ প্রযুক্তি পরিচিতি </option>

<option value="অধ্যায়-২:তথ্য ও যােগাযােগ প্রযুক্তি সংশ্লিষ্ট যন্ত্রপাতি"> অধ্যায়-২:তথ্য ও যােগাযােগ প্রযুক্তি সংশ্লিষ্ট যন্ত্রপাতি </option>

<option value="অধ্যায়-৩:তথ্য ও যােগাযােগ প্রযুক্তির নিরাপদ ব্যবহার"> অধ্যায়-৩:তথ্য ও যােগাযােগ প্রযুক্তির নিরাপদ ব্যবহার </option>

<option value="অধ্যায়-৪:ওয়ার্ড প্রসেসিং">অধ্যায়-৪:ওয়ার্ড প্রসেসিং</option>
<option value="অধ্যায়-৫:ইন্টারনেট পরিচিতি">অধ্যায়-৫:ইন্টারনেট পরিচিতি</option>


		<?php
	}







if ($subject=='ইসলাম ও নৈতিক শিক্ষা') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:আকাইদ">অধ্যায়-১:আকাইদ </option>

<option value="অধ্যায়-২: ইবাদত">অধ্যায়-২: ইবাদত </option>

<option value="অধ্যায়-৩: কুরআন ও হাদিস শিক্ষা">অধ্যায়-৩: কুরআন ও হাদিস শিক্ষা </option>

<option value="অধ্যায়-৪: আখলাক">অধ্যায়-৪: আখলাক </option>

<option value="অধ্যায়-৫:আদর্শ জীবনচরিত"> অধ্যায়-৫: আদর্শ জীবনচরিত </option>

		<?php
	}





if ($subject=='হিন্দু ধর্ম ও নৈতিক শিক্ষা') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১: স্রষ্টা ও সৃষ্টি"> অধ্যায়-১: স্রষ্টা ও সৃষ্টি</option>

<option value="অধ্যায়-২: ধর্মগ্রন্থ">অধ্যায়-২: ধর্মগ্রন্থ </option>
<option value="অধ্যায়-৩:হিন্দুধর্মের স্বরূপ ও বিশ্বাস">অধ্যায়-৩:হিন্দুধর্মের স্বরূপ ও বিশ্বাস </option>

<option value="অধ্যায়-৪:নিত্যকর্ম ও যােগাসন "> অধ্যায়-৪:নিত্যকর্ম ও যােগাসন </option>

<option value="অধ্যায়-৫:দেব-দেবী ও পূজা-পার্বণ">অধ্যায়-৫:দেব-দেবী ও পূজা-পার্বণ </option>

<option value="অধ্যায়-৬:ধর্মীয় উপাখ্যানে নৈতিক শিক্ষা"> অধ্যায়-৬:ধর্মীয় উপাখ্যানে নৈতিক শিক্ষা </option>

<option value="অধ্যায়-৭:আদর্শ জীবনচরিত"> অধ্যায়-৭:আদর্শ জীবনচরিত </option>

<option value="অধ্যায়-৮:হিন্দুধর্ম ও নৈতিক মূল্যবােধ"> অধ্যায়-৮:হিন্দুধর্ম ও নৈতিক মূল্যবােধ </option>


		<?php
	}




if ($subject=='বৌদ্ধ ধর্ম ও নৈতিক শিক্ষা') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১: গৌতম বুদ্ধের জীবপ্রেম">অধ্যায়-১: গৌতম বুদ্ধের জীবপ্রেম </option>
<option value="অধ্যায়-৩:বন্দনা">অধ্যায়-৩:বন্দনা </option>
<option value="অধ্যায়-৩:শীল">অধ্যায়-৩:শীল </option>
<option value="অধ্যায়-৪:দান">অধ্যায়-৪:দান </option>
<option value="অধ্যায়-৫:সূত্র ও নীতিগাথা"> অধ্যায়-৫:সূত্র ও নীতিগাথা </option>
<option value="অধ্যায়-৬:চতুরার্য সত্য"> অধ্যায়-৬:চতুরার্য সত্য </option>
<option value="অধ্যায়-৭:ধর্মীয় আচার-অনুষ্ঠান ও উৎসব"> অধ্যায়-৭:ধর্মীয় আচার-অনুষ্ঠান ও উৎসব </option>
<option value="অধ্যায়-৮:চরিতমালা"> অধ্যায়-৮:চরিতমালা </option>
<option value="অধ্যায়-৯:জাতক"> অধ্যায়-৯:জাতক </option>
<option value="অধ্যায়-১০:বাংলাদেশের বৌদ্ধ ঐতিহ্য ও দর্শনীয় স্থান">  অধ্যায়-১০:বাংলাদেশের বৌদ্ধ ঐতিহ্য ও দর্শনীয় স্থান </option>
<option value="অধ্যায়-১১:বৌদ্ধধর্মে রাজন্যবর্গের অবদান: রাজা বিম্বিসার"> অধ্যায়-১১:বৌদ্ধধর্মে রাজন্যবর্গের অবদান: রাজা বিম্বিসার </option>

		<?php
	}



if ($subject=='খ্রিস্টান ধর্ম ও নৈতিক শিক্ষা') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:ঈশ্বরকে জানা"> অধ্যায়-১:ঈশ্বরকে জানা </option>
<option value="অধ্যায়-২:ঈশ্বরের সৃষ্টিকর্মের উদ্দেশ্য">  অধ্যায়-২:ঈশ্বরের সৃষ্টিকর্মের উদ্দেশ্য </option>
<option value="অধ্যায়-৩:মানুষ সৃষ্টি"> অধ্যায়-৩:মানুষ সৃষ্টি  </option>
<option value="অধ্যায়-৪:স্বর্গদূত ও মানুষের পতন - পরিত্রাণের প্রতিশ্রুতি">  অধ্যায়-৪:স্বর্গদূত ও মানুষের পতন - পরিত্রাণের প্রতিশ্রুতি </option>
<option value="অধ্যায়-৫:ঈশ্বরের আহ্বানে ইসাইয়ার সাড়াদান">  অধ্যায়-৫:ঈশ্বরের আহ্বানে ইসাইয়ার সাড়াদান </option>
<option value="অধ্যায়-৬:মুক্তিদাতা যীশুর জন্ম ও শৈশব"> অধ্যায়-৬:মুক্তিদাতা যীশুর জন্ম ও শৈশব </option>
<option value="অধ্যায়-৭:প্রভু যীশুর আশ্চর্য কাজ">  অধ্যায়-৭:প্রভু যীশুর আশ্চর্য কাজ </option>
<option value="অধ্যায়-৮:খ্রিষ্টমণ্ডলীর জন্ম ও প্রেরণকর্ম"> অধ্যায়-৮:খ্রিষ্টমণ্ডলীর জন্ম ও প্রেরণকর্ম </option> 
<option value="অধ্যায়-৯:সত্যবাদিতা, শৃঙ্খলা ও সেবা"> অধ্যায়-৯:সত্যবাদিতা, শৃঙ্খলা ও সেবা </option>
<option value="অধ্যায়-১০:প্রিয়নাথ বৈরাগী"> অধ্যায়-১০:প্রিয়নাথ বৈরাগী </option>
	<?php
	}


if ($subject=='চারু ও কারু কলা') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:চারু ও কারুকলার পরিচয়"> অধ্যায়-১:চারু ও কারুকলার পরিচয় </option>

<option value="অধ্যায়-২:বাংলাদেশের চারু ও কারুকলা শিক্ষার ইতিহাস"> অধ্যায়-২:বাংলাদেশের চারু ও কারুকলা শিক্ষার ইতিহাস </option>

<option value="অধ্যায়-৩:বাংলাদেশের লােকশিল্প ও কারুশিল্প"> অধ্যায়-৩:বাংলাদেশের লােকশিল্প ও কারুশিল্প </option>

<option value="অধ্যায়-৪:ছবি আঁকার সাধারণ নিয়ম, উপকরণ ও মাধ্যম"> অধ্যায়-৪:ছবি আঁকার সাধারণ নিয়ম, উপকরণ ও মাধ্যম </option>

<option value="অধ্যায়-৫:ছবি আঁকার অনুশীলন"> অধ্যায়-৫:ছবি আঁকার অনুশীলন </option>

<option value="অধ্যায়-৬:কাগজ ও ফেলনা জিনিস দিয়ে শিল্পকর্ম">  অধ্যায়-৬:কাগজ ও ফেলনা জিনিস দিয়ে শিল্পকর্ম </option>

<option value="অধ্যায়-৭:রং ও রঙের ব্যবহার">অধ্যায়-৭: রং ও রঙের ব্যবহার </option>
internet download m
	<?php
	}

if ($subject=='কর্ম ও জীবনমুখী শিক্ষা') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:কর্মেই আনন্দ"> অধ্যায়-১:কর্মেই আনন্দ </option>

<option value="অধ্যায়-২:আমাদের প্রয়ােজনীয় কাজ"> অধ্যায়-২:আমাদের প্রয়ােজনীয় কাজ </option>

<option value="অধ্যায়-২:শিক্ষায় সাফল্য"> অধ্যায়-২:শিক্ষায় সাফল্য </option>

	<?php
	}
if ($subject=='শারীরিক শিক্ষা ও স্বাস্থ্য') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:শরীরচর্চা ও সুস্থ জীবন"> অধ্যায়-১:শরীরচর্চা ও সুস্থ জীবন </option>

<option value="অধ্যায়-৩:স্কাউটিং ও গার্ল গাইডিং"> অধ্যায়-৩:স্কাউটিং ও গার্ল গাইডিং </option>

<option value="অধ্যায়-৪:স্বাস্থ্যবিজ্ঞান পরিচিতি ও স্বাস্থ্যসেবা"> অধ্যায়-৪:স্বাস্থ্যবিজ্ঞান পরিচিতি ও স্বাস্থ্যসেবা </option>

<option value="অধ্যায়-৫:আমাদের জীবনে বয়ঃসন্ধিকাল"> অধ্যায়-৫: আমাদের জীবনে বয়ঃসন্ধিকাল </option>

<option value="অধ্যায়-৬:জীবনের জন্য খেলাধুলা"> অধ্যায়-৬:জীবনের জন্য খেলাধুলা </option>

	<?php
	}


if ($subject=='ক্ষুদ্র ও নৃগােষ্ঠীর ভাষা ও সংস্কৃতি') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:বাংলাদেশের সাংস্কৃতিক পরিচিতি"> অধ্যায়-১:বাংলাদেশের সাংস্কৃতিক পরিচিতি </option>

<option value="অধ্যায়-২:বাংলাদেশের ক্ষুদ্র নৃগােষ্ঠী পরিচিতি"> অধ্যায়-২:বাংলাদেশের ক্ষুদ্র নৃগােষ্ঠী পরিচিতি </option>

<option value="অধ্যায়-৩:ক্ষুদ্র নৃগােষ্ঠীর ভাষাপরিচয়"> অধ্যায়-৩:ক্ষুদ্র নৃগােষ্ঠীর ভাষাপরিচয় </option>

<option value="অধ্যায়-৪:ক্ষুদ্র নৃগােষ্ঠীর প্রত্নঐতিহ্য"> অধ্যায়-৪:ক্ষুদ্র নৃগােষ্ঠীর প্রত্নঐতিহ্য </option>

<option value="অধ্যায়-৫:ক্ষুদ্র নৃগােষ্ঠীর সমাজজীবন"> অধ্যায়-৫:ক্ষুদ্র নৃগােষ্ঠীর সমাজজীবন </option>

<option value="অধ্যায়-৬:ক্ষুদ্র নৃগােষ্ঠীর উৎসব"> অধ্যায়-৬:ক্ষুদ্র নৃগােষ্ঠীর উৎসব </option>


	<?php
	}

if ($subject=='গার্হস্থ্য বিজ্ঞান') {
		?>
<option value="">-- SELECT --</option>
<optgroup label="ক বিভাগ- গৃহ ও গৃহ ব্যবস্থাপনা">

<option value="অধ্যায়-১:গৃহ ও গৃহ পরিবেশের প্রাথমিক ধারণা">  অধ্যায়-১:গৃহ ও গৃহ পরিবেশের প্রাথমিক ধারণা </option>

<option value="অধ্যায়-২:গৃহের পরিষ্কার পরিচ্ছন্নতা"> অধ্যায়-২:গৃহের পরিষ্কার পরিচ্ছন্নতা </option>

<option value="অধ্যায়-৩:গৃহ ব্যবস্থাপনা"> অধ্যায়-৩:গৃহ ব্যবস্থাপনা </option>

</optgroup>

<optgroup label="খ বিভাগ- শিশু বিকাশ ও পারিবারিক সম্পর্ক">
	
<option value="অধ্যায়-৪:পরিবার ও শিশু"> অধ্যায়-৪:পরিবার ও শিশু </option>

<option value="অধ্যায়-৫:ছােটদের শিষ্টাচার শিক্ষা"> অধ্যায়-৫:ছােটদের শিষ্টাচার শিক্ষা </option>

<option value="অধ্যায়-৬:কৈশােরকালীন বিকাশ"> অধ্যায়-৬:কৈশােরকালীন বিকাশ </option>

<option value="অধ্যায়-৭: কৈশােরকালীন পরিবর্তন ও নিজের নিরাপত্তা রক্ষা"> অধ্যায়-৭: কৈশােরকালীন পরিবর্তন ও নিজের নিরাপত্তা রক্ষা </option>

</optgroup>
<optgroup label="গ-বিভাগ- খাদ্য ও খাদ্য ব্যবস্থপনা">

<option value="অধ্যায়-৮:খাদ্য, পুষ্টি ও স্বাস্থ্য"> অধ্যায়-৮:খাদ্য, পুষ্টি ও স্বাস্থ্য </option>

<option value="অধ্যায়-৯: খাদ্যের পুষ্টিমূল্য"> অধ্যায়-৯: খাদ্যের পুষ্টিমূল্য </option>

<option value="অধ্যায়-১০: খাদ্য চাহিদা"> অধ্যায়-১০: খাদ্য চাহিদা </option>

<option value="অধ্যায়-১১:খাদ্যাভ্যাস গঠন"> অধ্যায়-১১:খাদ্যাভ্যাস গঠন </option>
</optgroup>

<optgroup label="ঘ-বিভাগ-বস্ত্র ও পরিচ্ছদ">
<option value=" অধ্যায়-১২: বস্ত্র ও পরিচ্ছদের প্রাথমিক ধারণা"> অধ্যায়-১২: বস্ত্র ও পরিচ্ছদের প্রাথমিক ধারণা </option>
<option value=" অধ্যায়-১৩: বয়ন তন্তুর ধারণা"> অধ্যায়-১৩: বয়ন তন্তুর ধারণা </option>
<option value=" অধ্যায়-১৪: পোশাকের যত্ন ও সংরক্ষণ"> অধ্যায়-১৪: পোশাকের যত্ন ও সংরক্ষণ</option>
<option value=" অধ্যায়-১৫: সেলাইয়ের সরঞ্জাম ও বিভিন্ন ধরণের ফোঁড়"> অধ্যায়-১৫: সেলাইয়ের সরঞ্জাম ও বিভিন্ন ধরণের ফোঁড়</option>
</optgroup>
	<?php
	}
}
?>











































<?php 
if ($class==7) { 
if ($subject=='বাংলা প্রথম পত্র') {
		?>
<option value="">-- SELECT --</option>
<optgroup label="গদ্য">
<option value="অধ্যায়-১:কাবুলিওয়ালা"> অধ্যায়-১:কাবুলিওয়ালা  </option>

<option value="অধ্যায়-২:লখার একুশে"> অধ্যায়-২:লখার একুশে  </option>

<option value="অধ্যায়-৩:মরু-ভাস্কর"> অধ্যায়-৩:মরু-ভাস্কর  </option>

<option value="অধ্যায়-৪:শব্দ থেকে কবিতা"> অধ্যায়-৪:শব্দ থেকে কবিতা  </option>

<option value="অধ্যায়-৫:পাখি">  অধ্যায়-৫:পাখি   </option>

<option value="অধ্যায়-৬:পিতৃপুরুষের গল্প"> অধ্যায়-৬:পিতৃপুরুষের গল্প   </option>

<option value="অধ্যায়-৭:ছবির রং"> অধ্যায়-৭:ছবির রং  </option>

<option value="অধ্যায়-৮:রােকেয়া সাখাওয়াত হােসেন">অধ্যায়-৮:রােকেয়া সাখাওয়াত হােসেন   </option>

<option value="অধ্যায়-৯:সেই ছেলেটি">অধ্যায়-৯:সেই ছেলেটি</option>

<option value="অধ্যায়-১০:বাংলাদেশের ক্ষুদ্র জাতিসত্তা">অধ্যায়-১০:বাংলাদেশের ক্ষুদ্র জাতিসত্তা   </option>

</optgroup>



<optgroup label="কবিতা">
<option value="অধ্যায়-১:নতুন দেশ"> অধ্যায়-১:নতুন দেশ  </option>

<option value="অধ্যায়-২:কুলি-মজুর"> অধ্যায়-২:কুলি-মজুর  </option>

<option value="অধ্যায়-৩:আমার বাড়ি"> অধ্যায়-৩:আমার বাড়ি  </option>

<option value="অধ্যায়-৪:শােন একটি মুজিবরের থেকে"> অধ্যায়-৪:শােন একটি মুজিবরের থেকে </option>

<option value="অধ্যায়-৫:সবার আমি ছাত্র"> অধ্যায়-৫:সবার আমি ছাত্র  </option>

<option value="অধ্যায়-৬:শ্রাবণে"> অধ্যায়-৬:শ্রাবণে  </option>

<option value="অধ্যায়-৭:গরবিনী মা-জননী"> অধ্যায়-৭:গরবিনী মা-জননী  </option>

<option value="অধ্যায়-৮:সাম্য"> অধ্যায়-৮:সাম্য  </option>

<option value="অধ্যায়-৯:মেলা"> অধ্যায়-৯:মেলা  </option>

<option value="অধ্যায়-১০:এই অক্ষরে"> অধ্যায়-১০:এই অক্ষরে  </option>

</optgroup>

<optgroup label="আনন্দপাঠ">
<option value="অধ্যায়-১:তােতাকাহিনী"> অধ্যায়-১:তােতাকাহিনী </option>

<option value="অধ্যায়-২:গুরুচণ্ডালী"> অধ্যায়-২:গুরুচণ্ডালী </option>

<option value="অধ্যায়-৩:বুলু"> অধ্যায়-৩:বুলু </option>

<option value="অধ্যায়-৪:মানুষের মন"> অধ্যায়-৪:মানুষের মন </option>

<option value="অধ্যায়-৫:আদুভাই"> অধ্যায়-৫:আদুভাই </option>

<option value="অধ্যায়-৬:অলক্ষুণে জুতাে"> অধ্যায়-৬:অলক্ষুণে জুতাে </option>

<option value="অধ্যায়-৭:উনিশ শ’ একাত্তর"> অধ্যায়-৭:উনিশ শ’ একাত্তর </option>

<option value="অধ্যায়-৮:বিচার নেই"> অধ্যায়-৮:বিচার নেই </option>

<option value="অধ্যায়-৯:চরু">  অধ্যায়-৯:চরু </option>

</optgroup>

		<?php
	}
if ($subject=='বাংলা দ্বিতীয় পত্র') {
		?>
<option value="">-- SELECT --</option>
<optgroup label="ব্যাকরণ">
<option value="অধ্যায়-১:ভাষা">অধ্যায়-১:ভাষা</option>
<option value="অধ্যায়-২:ব্যাকরণ">অধ্যায়-২:ব্যাকরণ</option>
<option value="অধ্যায়-৩:ধ্বনি ও বর্ণ">অধ্যায়-৩:ধ্বনি ও বর্ণ</option>
<option value="অধ্যায়-৪.সন্ধি">অধ্যায়-৪.সন্ধি</option>
<option value="অধ্যায়-৫:শব্দ ও পদ">অধ্যায়-৫:শব্দ ও পদ</option>
<option value="অধ্যায়-৫.১:কারক ও বিভক্তি">অধ্যায়-৫.১:কারক ও বিভক্তি</option>
<option value="অধ্যায়-৫:২ সম্বন্ধ ও সম্বোধন পদ">অধ্যায়-৫:২ সম্বন্ধ ও সম্বোধন পদ</option>
<option value="অধ্যায়-৫:৩ শব্দরূপ">অধ্যায়-৫:৩ শব্দরূপ</option>
<option value="অধ্যায়-৫:৪ বিশেষণের 'তর' ও 'তম'">অধ্যায়-৫:৪ বিশেষণের ‘তর ও 'তম'</option>
<option value="অধ্যায়-৬:শব্দগঠন">অধ্যায়-৬:শব্দগঠন</option>
<option value="অধ্যায়-৬.১:উপসর্গযােগে শব্দগঠন">অধ্যায়-৬.১:উপসর্গযােগে শব্দগঠন</option>
<option value="অধ্যায়-৬.২:প্রত্যয়যােগে শব্দগঠন">অধ্যায়-৬.২:প্রত্যয়যােগে শব্দগঠন</option>
<option value="অধ্যায়-৭:বাক্য">অধ্যায়-৭:বাক্য</option>
<option value="অধ্যায়-৮:বিরামচিহ্ন">অধ্যায়-৮:বিরামচিহ্ন</option>
<option value="অধ্যায়-৯:বানান">অধ্যায়-৯:বানান</option>
<option value="অধ্যায়-১০:শব্দার্থ">অধ্যায়-১০:শব্দার্থ</option>
<option value="অধ্যায়-১০.১:একই শব্দ বিভিন্ন অর্থে  প্রয়ােগ">অধ্যায়-১০.১:একই শব্দ বিভিন্ন অর্থে  প্রয়ােগ</option>
<option value="অধ্যায়-১০.২:বিপরীতার্থক শব্দ দিয়ে বাক্য রচনা">অধ্যায়-১০.২:বিপরীতার্থক শব্দ দিয়ে বাক্য রচনা</option>
<option value="অধ্যায়-১০.৩: সমােচ্চারিত ভিন্নার্থক শব্দ দিয়ে বাক্য রচনা">অধ্যায়-১০.৩: সমােচ্চারিত ভিন্নার্থক শব্দ দিয়ে বাক্য রচনা</option>
<option value="অধ্যায়-১০.৪:এক কথায় প্রকাশ">অধ্যায়-১০.৪:এক কথায় প্রকাশ</option>
<option value="অধ্যায়-১০.৫:বাগধারা">অধ্যায়-১০.৫:বাগধারা</option>

</optgroup>
<optgroup label="নির্মিতি">
	
<option value="অধ্যায়-১১.১: রচনা">অধ্যায়-১১.১: রচনা</option>
<option value="অধ্যায়-১১:২ অনুধাবন দক্ষতা">অধ্যায়-১১:২ অনুধাবন দক্ষতা</option>
<option value="অধ্যায়-১১:৩ সারমর্ম/সারাংশ">অধ্যায়-১১:৩ সারমর্ম/সারাংশ</option>
<option value="অধ্যায়-১১:৪ ভাবসম্প্রসারণ">অধ্যায়-১১:৪ ভাবসম্প্রসারণ</option>
<option value="অধ্যায়-১১:৫ আবেদনপত্র ও চিঠি">অধ্যায়-১১:৫ আবেদনপত্র ও চিঠি</option>
</optgroup>
		<?php
	}
if ($subject=='ইংরেজি প্রথম পত্র') {
		?>
<option value="">-- SELECT --</option>
<option value="Unit-1:Attention, please"> Unit-1:Attention, please </option>

<option value="Unit-2:My study guide">Unit-2:My study guide </option>

<option value="Unit-3:What are friends for?">Unit-3:What are friends for? </option>

<option value="Unit-4:People who make a difference">Unit-4:People who make a difference </option>

<option value="Unit-5:Great women to remember">Unit-5:Great women to remember </option>

<option value="Unit-6:Leisure">Unit-6:Leisure </option>

<option value="Unit-7:Games and sports"> Unit-7:Games and sports </option>

<option value="Unit-8:Likes and dislikes"> Unit-8:Likes and dislikes </option>

<option value="Unit-9:Climate change"> Unit-9:Climate change </option>

		<?php
	}



if ($subject=='ইংরেজি দ্বিতীয় পত্র') {
		?>
<option value="">-- SELECT --</option>
<optgroup label="Grammar">
<option value="Unit-1:Parts of Speech">Unit-1:Parts of Speech </option>

<option value="Unit-2:Modals">Unit-2:Modals </option>

<option value="Unit-3:The Tense">Unit-3:The Tense </option>

<option value="Unit-4:Forms of Verbs">Unit-4:Forms of Verbs</option>

<option value="Unit-5:More about Adjectives">Unit-5:More about Adjectives </option>

<option value="Unit-6:More about Adverbs">Unit-6:More about Adverbs </option>

<option value="Unit-7:More about Prepositions">Unit-7:More about Prepositions </option>

<option value="Unit-8:Linking Words">Unit-8:Linking Words </option>

<option value="Unit-9:Introducing Articles">Unit-9:Introducing Articles </option>

<option value="Unit-10:Possessives">Unit-10:Possessives </option>

<option value="Unit-11:The Sentence">Unit-11:The Sentence </option>

<option value="Unit-12:Introductory 'There'">Unit-12:Introductory 'There' </option>

<option value="Unit-13:There isn't/ There aren't">Unit-13:There isn't/ There aren't </option>

<option value="Unit-14:Infinitives, Gerunds and  Participles"> Unit-14:Infinitives, Gerunds and  Participles </option>

<option value="Unit-15:Capitalization and Punctuation">Unit-15:Capitalization and Punctuation </option>

<option value="Unit-16:Direct Speech and Indirect Speech">Unit-16:Direct Speech and Indirect Speech</option>

<option value="Unit-17:Voice">Unit-17:Voice</option>

</optgroup>
<optgroup label="Composition">
<option value="Unit-18:Writing Paragraphs">Unit-18:Writing Paragraphs</option>
<option value="Unit-19:Writing Paragraphs">Unit-18:Letter Writing</option>
</optgroup>
		<?php
	}





if ($subject=='গনিত') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:মূলদ ও অমূলদ সংখ্যা">অধ্যায়-১:মূলদ ও অমূলদ সংখ্যা </option>

<option value="অধ্যায়-২:সমানুপাত ও লাভ-ক্ষতি">অধ্যায়-২:সমানুপাত ও লাভ-ক্ষতি </option>

<option value="অধ্যায়-৩:পরিমাপ">অধ্যায়-৩:পরিমাপ </option>

<option value="অধ্যায়-৪:বীজগণিতীয় রাশির গুণ ও ভাগ">অধ্যায়-৪:বীজগণিতীয় রাশির গুণ ও ভাগ </option>

<option value="অধ্যায়-৫:বীজগণিতীয় সূত্রাবলি ও প্রয়ােগ">অধ্যায়-৫:বীজগণিতীয় সূত্রাবলি ও প্রয়ােগ </option>

<option value="অধ্যায়-৬:বীজগণিতীয় ভগ্নাংশ">অধ্যায়-৬:বীজগণিতীয় ভগ্নাংশ </option>

<option value="অধ্যায়-৭:সরল সমীকরণ">অধ্যায়-৭:সরল সমীকরণ </option>

<option value="অধ্যায়-৮:সমান্তরাল সরলরেখা">অধ্যায়-৮:সমান্তরাল সরলরেখা </option>

<option value="অধ্যায়-৯:ত্রিভুজ">অধ্যায়-৯:ত্রিভুজ </option>

<option value="অধ্যায়-১০:সর্বসমতা ও সদৃশতা">অধ্যায়-১০:সর্বসমতা ও সদৃশতা </option>

<option value="অধ্যায়-১১:তথ্য ও উপাত্ত">অধ্যায়-১১:তথ্য ও উপাত্ত </option>

		<?php
	}


	

if ($subject=='বিজ্ঞান') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:নিম্নশ্রেণির জীব">অধ্যায়-১:নিম্নশ্রেণির জীব </option>

<option value="অধ্যায়-২:উদ্ভিদ ও প্রাণীর কোষীয় সংগঠন">অধ্যায়-২:উদ্ভিদ ও প্রাণীর কোষীয় সংগঠন </option>

<option value="অধ্যায়-৩: উদ্ভিদের বাহ্যিক বৈশিষ্ট্য">অধ্যায়-৩: উদ্ভিদের বাহ্যিক বৈশিষ্ট্য </option>


<option value="অধ্যায়-৪: শ্বসন">অধ্যায়-৪: শ্বসন </option>

<option value="অধ্যায়-৫:পরিপাকতন্ত্র এবং রক্ত সংবহনতন্ত্র">অধ্যায়-৫:পরিপাকতন্ত্র এবং রক্ত সংবহনতন্ত্র </option>

<option value="অধ্যায়-৬:পদার্থের গঠন">অধ্যায়-৬:পদার্থের গঠন </option>

<option value="অধ্যায়-৭:শক্তির ব্যবহার">অধ্যায়-৭:শক্তির ব্যবহার </option>

<option value="অধ্যায়-৮:শব্দের কথা">অধ্যায়-৮:শব্দের কথা </option>

<option value="অধ্যায়-৯:তাপ ও তাপমাত্রা">অধ্যায়-৯:তাপ ও তাপমাত্রা </option>

<option value="অধ্যায়-১০:বিদ্যুৎ ও চুম্বকের ঘটনা">অধ্যায়-১০:বিদ্যুৎ ও চুম্বকের ঘটনা </option>

<option value="অধ্যায়-১১:পারিপার্শ্বিক পরিবর্তন ও বিভিন্ন ঘটনা">অধ্যায়-১১:পারিপার্শ্বিক পরিবর্তন ও বিভিন্ন ঘটনা </option>

<option value="অধ্যায়-১২:সৌরজগৎ ও আমাদের পৃথিবী">সৌরজগৎ ও আমাদের পৃথিবী </option>

<option value="অধ্যায়-১৩:প্রাকৃতিক পরিবেশ এবং দূষণ">অধ্যায়-১৩:প্রাকৃতিক পরিবেশ এবং দূষণ </option>

<option value="অধ্যায়-১৪:জলবায়ু পরিবর্তন">অধ্যায়-১৪:জলবায়ু পরিবর্তন </option>

		<?php
	}

	

if ($subject=='বাংলাদেশ ও বিশ্ব পরিচয়') {
		?>

<option value="অধ্যায়-১:বাংলাদেশের স্বাধীনতা সংগ্রাম">অধ্যায়-১:বাংলাদেশের স্বাধীনতা সংগ্রাম </option>

<option value="অধ্যায়-২:বাংলাদেশের সংস্কৃতি ও সাংস্কৃতিক বৈচিত্র্য">অধ্যায়-২:বাংলাদেশের সংস্কৃতি ও সাংস্কৃতিক বৈচিত্র্য </option>

<option value="অধ্যায়-৩:পরিবারে শিশুর বেড়ে ওঠা">অধ্যায়-৩:পরিবারে শিশুর বেড়ে ওঠা </option>

<option value="অধ্যায়-৪:বাংলাদেশের অর্থনীতি">অধ্যায়-৪:বাংলাদেশের অর্থনীতি </option>

<option value="অধ্যায়-৫:বাংলাদেশ ও বাংলাদেশের নাগরিক">অধ্যায়-৫:বাংলাদেশ ও বাংলাদেশের নাগরিক </option>

<option value="অধ্যায়-৬:বাংলাদেশের নির্বাচন ব্যবস্থা">অধ্যায়-৬:বাংলাদেশের নির্বাচন ব্যবস্থা </option>

<option value="অধ্যায়-৭:বাংলাদেশের জলবায়ু">অধ্যায়-৭:বাংলাদেশের জলবায়ু </option>

<option value="অধ্যায়-৮:বাংলাদেশের জনসংখ্যা পরিচিতি">অধ্যায়-৮:বাংলাদেশের জনসংখ্যা পরিচিতি </option>

<option value="অধ্যায়-৯:বাংলাদেশের প্রবীণ ব্যক্তি ও নারী অধিকার">অধ্যায়-৯:বাংলাদেশের প্রবীণ ব্যক্তি ও নারী অধিকার </option>

<option value="অধ্যায়-১০:বাংলাদেশের সামাজিক সমস্যা">অধ্যায়-১০:বাংলাদেশের সামাজিক সমস্যা </option>


<option value="অধ্যায়-১১:এশিয়ার কয়েকটি দেশ">অধ্যায়-১১:এশিয়ার কয়েকটি দেশ </option>

<option value="অধ্যায়-১২:বাংলাদেশ ও আন্তর্জাতিক সহযােগিতা">অধ্যায়-১২:বাংলাদেশ ও আন্তর্জাতিক সহযােগিতা </option>

<option value="অধ্যায়-১৩:টেকসই উন্নয়ন অভীষ্ট (এসডিজি)">অধ্যায়-১৩:টেকসই উন্নয়ন অভীষ্ট (এসডিজি)  </option>



		<?php
	}
	

if ($subject=='কৃষিশিক্ষা') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:কৃষি এবং আমাদের সংস্কৃতি">অধ্যায়-:১কৃষি এবং আমাদের সংস্কৃতি </option>

<option value="অধ্যায়-২:কৃষি প্রযুক্তি">অধ্যায়-২:কৃষি প্রযুক্তি </option>


<option value="অধ্যায়-৩:কৃষি উপকরণ">অধ্যায়-৩:কৃষি উপকরণ </option>

<option value="অধ্যায়-৪:কৃষি ও জলবায়ু">অধ্যায়-৪:কৃষি ও জলবায়ু </option>


<option value="অধ্যায়-৫:কৃষিজ উৎপাদন">অধ্যায়-৫:কৃষিজ উৎপাদন </option>

<option value="অধ্যায়-৬:বনায়ন">অধ্যায়-৬:বনায়ন </option>

		<?php
	}	









if ($subject=='তথ্য ও যোগাযোগ প্রযুক্তি') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১: প্রাত্যহিক জীবনে তথ্য ও যোগাযোগ প্রযুক্তি">অধ্যায়-১: প্রাত্যহিক জীবনে তথ্য ও যোগাযোগ প্রযুক্তি</option>

<option value="অধ্যায়-২:কম্পিউটার-সংশ্লিষ্ট যন্ত্রপাতি">অধ্যায়-২:কম্পিউটার-সংশ্লিষ্ট যন্ত্রপাতি</option>


<option value="অধ্যায়-৩:নিরাপদ ও নৈতিক ব্যবহার">অধ্যায়-৩:নিরাপদ ও নৈতিক ব্যবহার</option>

<option value="অধ্যায়-৪:ওয়ার্ড প্রসেসিং">অধ্যায়-৪:ওয়ার্ড প্রসেসিং</option>


<option value="অধ্যায়-৫:শিক্ষায় ইন্টারনেটের ব্যবহার">অধ্যায়-৫:শিক্ষায় ইন্টারনেটের ব্যবহার</option>

		<?php
	}







if ($subject=='ইসলাম ও নৈতিক শিক্ষা') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:আকাইদ"> অধ্যায়-১:আকাইদ </option>

<option value="অধ্যায়-২:ইবাদত"> অধ্যায়-২:ইবাদত </option>

<option value="অধ্যায়-৩:কুরআন ও হাদিস শিক্ষা"> অধ্যায়-৩:কুরআন ও হাদিস শিক্ষা </option>

<option value="অধ্যায়-৪:আখলাক"> অধ্যায়-৪:আখলাক </option>

<option value="অধ্যায়-৫:আদর্শ জীবনচরিত"> অধ্যায়-৫:আদর্শ জীবনচরিত </option>

		<?php
	}





if ($subject=='হিন্দু ধর্ম ও নৈতিক শিক্ষা') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:ঈশ্বরের স্বরূপ"> অধ্যায়-১:ঈশ্বরের স্বরূপ </option>

<option value="অধ্যায়-২:ধর্মগ্রন্থ"> অধ্যায়-২:ধর্মগ্রন্থ </option>

<option value="অধ্যায়-৩: হিন্দুধর্মের স্বরূপ ও বিশ্বাস"> অধ্যায়-৩: হিন্দুধর্মের স্বরূপ ও বিশ্বাস </option>

<option value="অধ্যায়-৪:নিত্যকর্ম ও যােগাসন"> অধ্যায়-৪:নিত্যকর্ম ও যােগাসন </option>

<option value="অধ্যায়-৫:দেব-দেবী ও পূজা-পার্বণ"> অধ্যায়-৫:দেব-দেবী ও পূজা-পার্বণ </option>

<option value="অধ্যায়-৬:ধর্মীয় উপাখ্যানে নৈতিক শিক্ষা"> অধ্যায়-৬:ধর্মীয় উপাখ্যানে নৈতিক শিক্ষা </option>

<option value="অধ্যায়-৭:আদর্শ জীবনচরিত"> অধ্যায়-৭:আদর্শ জীবনচরিত </option>

<option value="অধ্যায়-৮:হিন্দুধর্ম ও নৈতিক মূল্যবোেধ"> অধ্যায়-৮:হিন্দুধর্ম ও নৈতিক মূল্যবোধ </option>

		<?php
	}




if ($subject=='বৌদ্ধ ধর্ম ও নৈতিক শিক্ষা') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:গৌতম বুদ্ধের নৈতিক শিক্ষা"> অধ্যায়-১:গৌতম বুদ্ধের নৈতিক শিক্ষা </option>

<option value="অধ্যায়-২:বন্দনা"> অধ্যায়-২:বন্দনা </option>

<option value="অধ্যায়-৩:শীল"> অধ্যায়-৩:শীল </option>

<option value="অধ্যায়-৪:দান"> অধ্যায়-৪:দান </option>

<option value="অধ্যায়-৫:সূত্র ও নীতিগাথা"> অধ্যায়-৫:সূত্র ও নীতিগাথা </option>

<option value="অধ্যায়-৬আর্য অষ্টাঙ্গিক মার্গ"> অধ্যায়-৬আর্য অষ্টাঙ্গিক মার্গ </option>

<option value="অধ্যায়-৭:ধর্মীয় আচার-অনুষ্ঠান ও উৎসব"> অধ্যায়-৭:ধর্মীয় আচার-অনুষ্ঠান ও উৎসব </option>

<option value="অধ্যায়-৮:চরিতমালা"> অধ্যায়-৮:চরিতমালা </option>

<option value="অধ্যায়-৯:জাতক"> অধ্যায়-৯:জাতক </option>

<option value="অধ্যায়-১০:বৌদ্ধ ঐতিহ্য ও দর্শনীয় স্থান"> অধ্যায়-১০:বৌদ্ধ ঐতিহ্য ও দর্শনীয় স্থান </option>

<option value="অধ্যায়-১১:বৌদ্ধধর্মে রাজন্যবর্গের অবদান: সম্রাট অশােক"> অধ্যায়-১১:বৌদ্ধধর্মে রাজন্যবর্গের অবদান: সম্রাট অশােক </option> 

		<?php
	}



if ($subject=='খ্রিস্টান ধর্ম ও নৈতিক শিক্ষা') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:ঈশ্বরের অদ্বিতীয় পুত্র যীশু খ্রিষ্ট"> অধ্যায়-১:ঈশ্বরের অদ্বিতীয় পুত্র যীশু খ্রিষ্ট </option>

<option value="অধ্যায়-২: ঈশ্বরের সৃষ্টি উত্তম"> অধ্যায়-২: ঈশ্বরের সৃষ্টি উত্তম </option>


<option value="অধ্যায়-৩:দেহ, মন ও আত্মাসম্পন্ন মানুষ"> অধ্যায়-৩:দেহ, মন ও আত্মাসম্পন্ন মানুষ </option>

<option value="অধ্যায়-৪:পাপ"> অধ্যায়-৪:পাপ </option>


<option value="অধ্যায়-৫:মুক্তিদাতা যীশুর জীবন ও কাজ">  অধ্যায়-৫:মুক্তিদাতা যীশুর জীবন ও কাজ </option>

<option value="অধ্যায়-৬:ঈশ্বরের আহ্বানে মারীয়ার সাড়াদান">  অধ্যায়-৬:ঈশ্বরের আহ্বানে মারীয়ার সাড়াদান </option>

<option value="অধ্যায়-৭:যীশুর আশ্চর্য কাজ ও ঐশরাজ্য">  অধ্যায়-৭:যীশুর আশ্চর্য কাজ ও ঐশরাজ্য </option>


<option value="অধ্যায়-৮:খ্রিষ্টমণ্ডলী এক, পবিত্র ও প্রৈরিতিক"> অধ্যায়-৮:খ্রিষ্টমণ্ডলী এক, পবিত্র ও প্রৈরিতিক </option>


<option value="অধ্যায়-৯:ক্ষমা, সহনশীলতা ও দেশপ্রেম"> অধ্যায়-৯:ক্ষমা, সহনশীলতা ও দেশপ্রেম </option>


<option value="অধ্যায়-১০:ফাদার চার্লস যােসেফ ইয়াং"> অধ্যায়-১০:ফাদার চার্লস যােসেফ ইয়াং </optin>


	<?php
	}


if ($subject=='চারু ও কারু কলা') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:বাংলাদেশে চারুকলা শিক্ষার ইতিহাস">অধ্যায়-১:বাংলাদেশে চারুকলা শিক্ষার ইতিহাস</option>

<option value="অধ্যায়-২:চিত্রকলা সর্বকালে সব মানুষের ভাষা"> অধ্যায়-২:চিত্রকলা সর্বকালে সব মানুষের ভাষা </option>

<option value="অধ্যায়-৩:বাংলাদেশের লােকশিল্প ও কারুশিল্প"> অধ্যায়-৩:বাংলাদেশের লােকশিল্প ও কারুশিল্প </option>

<option value="অধ্যায়-৪:ছবি আঁকার বিভিন্ন মাধ্যম"> অধ্যায়-৪:ছবি আঁকার বিভিন্ন মাধ্যম </option>

<option value="অধ্যায়-৫:ছবি আঁকার নানারকম আনন্দদায়ক অনুশীলন"> অধ্যায়-৫:ছবি আঁকার নানারকম আনন্দদায়ক অনুশীলন </option>

<option value="অধ্যায়-৬:বিভিন্ন প্রকার শিল্পকর্ম"> অধ্যায়-৬:বিভিন্ন প্রকার শিল্পকর্ম </option>

<option value="অধ্যায়-৭:রঙ ও রঙের ব্যবহার"> অধ্যায়-৭:রঙ ও রঙের ব্যবহার </option>

	<?php
	}

if ($subject=='কর্ম ও জীবনমুখী শিক্ষা') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:কর্ম ও মানবিকতা"> অধ্যায়-১:কর্ম ও মানবিকতা </option>

<option value="অধ্যায়-২:পারিবারিক কাজ ও পেশা"> অধ্যায়-২:পারিবারিক কাজ ও পেশা </option>

<option value="অধ্যায়-৩:শিক্ষা পরিকল্পনা ও কর্মক্ষেত্রে সফলতা">  অধ্যায়-৩:শিক্ষা পরিকল্পনা ও কর্মক্ষেত্রে সফলতা </option>


	<?php
	}
if ($subject=='শারীরিক শিক্ষা ও স্বাস্থ্য') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:শরীরচর্চা ও সুস্থজীবন"> অধ্যায়-১:শরীরচর্চা ও সুস্থজীবন </option>

<option value="অধ্যায়-২:স্কাউটিং ও গার্ল গাইডিং"> অধ্যায়-২:স্কাউটিং ও গার্ল গাইডিং </option>

<option value="অধ্যায়-৩:স্বাস্থ্যবিজ্ঞান পরিচিতি ও স্বাস্থ্যসেবা"> অধ্যায়-৩:স্বাস্থ্যবিজ্ঞান পরিচিতি ও স্বাস্থ্যসেবা </option>

<option value="অধ্যায়-৪:বয়ঃসন্ধিকালের ব্যক্তিগত নিরাপত্তা"> অধ্যায়-৪:বয়ঃসন্ধিকালের ব্যক্তিগত নিরাপত্তা </option>

<option value="অধ্যায়-৫:জীবনের জন্য খেলাধুলা"> অধ্যায়-৫:জীবনের জন্য খেলাধুলা</option>

	<?php
	}


if ($subject=='ক্ষুদ্র ও নৃগােষ্ঠীর ভাষা ও সংস্কৃতি') {
		?>
<option value="">-- SELECT --</option>
<option value="অধ্যায়-১:ক্ষুদ্র নৃগােষ্ঠীর সাংস্কৃতিক পরিচিতি">  অধ্যায়-১:ক্ষুদ্র নৃগােষ্ঠীর সাংস্কৃতিক পরিচিতি </option>

<option value="অধ্যায়-২:ক্ষুদ্র নৃগােষ্ঠীর বিশ্বাস ও মূল্যবােধ"> অধ্যায়-২:ক্ষুদ্র নৃগােষ্ঠীর বিশ্বাস ও মূল্যবােধ </option>

<option value="অধ্যায়-৩:ক্ষুদ্র নৃগােষ্ঠীর রাজনৈতিক জীবন"> অধ্যায়-৩:ক্ষুদ্র নৃগােষ্ঠীর রাজনৈতিক জীবন </option>

<option value="অধ্যায়-৪:আন্দোলন ও সংগ্রামে ক্ষুদ্র নৃগােষ্ঠী"> অধ্যায়-৪:আন্দোলন ও সংগ্রামে ক্ষুদ্র নৃগােষ্ঠী </option>

<option value="অধ্যায়-৫:ক্ষুদ্র নৃগােষ্ঠীর লােকজ জ্ঞান"> অধ্যায়-৫:ক্ষুদ্র নৃগােষ্ঠীর লােকজ জ্ঞান </option>

<option value="অধ্যায়-৬:জীববৈচিত্র্য ও পরিবেশ সংরক্ষণে ক্ষুদ্র নৃগােষ্ঠী"> অধ্যায়-৬:জীববৈচিত্র্য ও পরিবেশ সংরক্ষণে ক্ষুদ্র নৃগােষ্ঠী </option>

	<?php
	}

if ($subject=='গার্হস্থ্য বিজ্ঞান') {
		?>
<option value="">-- SELECT --</option>
<optgroup label="ক বিভাগ- গৃহ ব্যবস্থাপনা ও গৃহ সম্পদ">

<option value="অধ্যায়-১:গৃহ ব্যবস্থাপনার স্তর ও গৃহ সম্পদ">  অধ্যায়-১:গৃহ ব্যবস্থাপনার স্তর ও গৃহ সম্পদ </optin>

<option value="অধ্যায়-২:গৃহসামগ্রী ক্রয়">  অধ্যায়-২:গৃহসামগ্রী ক্রয় </optin>

<option value="অধ্যায়-৩: গৃহকে মনােরম ও আকর্ষণীয় করার নীতি">  অধ্যায়-৩: গৃহকে মনােরম ও আকর্ষণীয় করার নীতি </optin>


</optgroup>

<optgroup label="খ বিভাগ- শিশুর বিকাশ ও সামাজিক সম্পর্ক">
	
<option value="অধ্যায়-৪:পরিবার ও সমাজের সদস্য হিসেবে শিশু"> অধ্যায়-৪:পরিবার ও সমাজের সদস্য হিসেবে শিশু </optin>

<option value="অধ্যায়-৫: শিশুর বিকাশে খেলাধুলা"> অধ্যায়-৫: শিশুর বিকাশে খেলাধুলা </optin>

<option value="অধ্যায়-৬:প্রতিবন্ধী শিশু"> অধ্যায়-৬:প্রতিবন্ধী শিশু </optin>

<option value="অধ্যায়-৭:জাতিসংঘ সনদ অনুযায়ী শিশুর অধিকার"> অধ্যায়-৭:জাতিসংঘ সনদ অনুযায়ী শিশুর অধিকার </optin>

</optgroup>
<optgroup label="গ-বিভাগ- খাদ্য , পুষ্টি ও স্বাস্থ্য">

<option value="অধ্যায়-৮:খাদ্য উপাদান, পরিপাক ও শােষণ"> অধ্যায়-৮:খাদ্য উপাদান, পরিপাক ও শােষণ </optin>

<option value="অধ্যায়-৯:মৌলিক খাদ্যগোষ্ঠী"> অধ্যায়-৯:মৌলিক খাদ্যগোষ্ঠী </optin>

<option value="অধ্যায়-১০:রােগীর পথ্য ও পথ্য পরিকল্পনা"> অধ্যায়-১০:রােগীর পথ্য ও পথ্য পরিকল্পনা </optin>

<option value="অধ্যায়-১১:খাদ্য সংরক্ষণ"> অধ্যায়-১১:খাদ্য সংরক্ষণ </optin>

</optgroup>

<optgroup label="ঘ-বিভাগ-বস্ত্ পরিচ্ছদ ও বয়ন তন্তু">
<option value="অধ্যায়-১২:বয়ন তন্তুর গুণাগুণ">অধ্যায়-১২:বয়ন তন্তুর গুণাগুণ </optin>
<option value="অধ্যায়-১৩:বত্র অলংকরণ">অধ্যায়-১৩:বত্র অলংকরণ </optin>
<option value="অধ্যায়-১৪:পশাকের পারিপাট্য ও ব্যক্তিত্ব">অধ্যায়-১৪:পশাকের পারিপাট্য ও ব্যক্তিত্ব </optin>
<option value="অধ্যায়-১৫:পোশাকের পরিচ্ছন্নতা">অধ্যায়-১৫: পোশাকের পরিচ্ছন্নতা </optin>
</optgroup>
	<?php
	}
}

?>




























<?php 
if ($class==8) { 
if ($subject=='বাংলা প্রথম পত্র') {
		?>
<option value="">-- SELECT --</option>
<optgroup label="গদ্য">
<option value="অধ্যায়-১:অতিথির স্মৃতি">অধ্যায়-১:অতিথির স্মৃতি</option>

<option value="অধ্যায়-২:ভাব ও কাজ">অধ্যায়-২:ভাব ও কাজ</option>

<option value="অধ্যায়-৩:পড়ে পাওয়া"> অধ্যায়-৩:পড়ে পাওয়া</option>

<option value="অধ্যায়-৪:তৈলচিত্রের ভূত">অধ্যায়-৪:তৈলচিত্রের ভূত</option>

<option value="অধ্যায়-৫:এবারের সংগ্রাম স্বাধীনতার সংগ্রাম">  অধ্যায়-৫:এবারের সংগ্রাম স্বাধীনতার সংগ্রাম</option>

<option value="অধ্যায়-৬:আমাদের লোকশিল্প"> অধ্যায়-৬:আমাদের লোকশিল্প</option>

<option value="অধ্যায়-৭:সুখী মানুষ">অধ্যায়-৭:সুখী মানুষ</option>

<option value="অধ্যায়-৮:শিল্পকলার নানা দিক">অধ্যায়-৮:শিল্পকলার নানা দিক</option>

<option value="অধ্যায়-৯:মংডুর পথে">অধ্যায়-৯:মংডুর পথে</option>

<option value="অধ্যায়-১০:বাংলা নববর্ষ">অধ্যায়-১০:বাংলা নববর্ষ</option>

</optgroup>



<optgroup label="কবিতা">
<option value="অধ্যায়-১: মানবধর্ম">অধ্যায়-১২: মানবধর্ম</option>

<option value="অধ্যায়-২:বঙ্গভূমির প্রতি">অধ্যায়-২:বঙ্গভূমির প্রতি</option>

<option value="অধ্যায়-৩:দুই বিঘা জমি">অধ্যায়-৩:দুই বিঘা জমি</option>

<option value="অধ্যায়-৪:পাছে লোকে কিছু বলে">অধ্যায়-৪:পাছে লোকে কিছু বলে</option>

<option value="অধ্যায়-৫:প্রার্থনা">অধ্যায়-৫:প্রার্থনা</option>

<option value="অধ্যায়-৬:বাবুরের মহত্ত্ব">অধ্যায়-৬:বাবুরের মহত্ত্ব</option>

<option value="অধ্যায়-৭:নারী">অধ্যায়-৭:নারী</option>

<option value="অধ্যায়-৮:আবার আসিব ফিরে">অধ্যায়-৮:আবার আসিব ফিরে</option>

<option value="অধ্যায়-৯:রুপাই">অধ্যায়-৯:রুপাই</option>

<option value="অধ্যায়-১০:নদীর স্বপ্ন">অধ্যায়-১০:নদীর স্বপ্ন</option>
<option value="অধ্যায়-১১:জাগো তবে অরণ্য কন্যারা">অধ্যায়-১১:জাগো তবে অরণ্য কন্যারা</option>
<option value="অধ্যায়-১২:প্রার্থী">অধ্যায়-১২:প্রার্থী</option>
<option value="অধ্যায়-১৩:একুশের গান">অধ্যায়-১৩:একুশের গান</option>

</optgroup>

<optgroup label="আনন্দপাঠ">
<option value="অধ্যায়-১:কিশোর কাজি">অধ্যায়-১:কিশোর কাজি</option>

<option value="অধ্যায়-২:রাজকুমার ও ভিখারির ছেলে">অধ্যায়-২:রাজকুমার ও ভিখারির ছেলে</option>

<option value="অধ্যায়-৩:রবিনসন ক্রুশো">অধ্যায়-৩:রবিনসন ক্রুশো</option>

<option value="অধ্যায়-৪:সোহরাব রোস্তম">অধ্যায়-৪:সোহরাব রোস্তম</option>

<option value="অধ্যায়-৫:মার্চেন্ট অব ভেনিস">অধ্যায়-৫:মার্চেন্ট অব ভেনিস</option>

<option value="অধ্যায়-৬:রিপভ্যান উইংকল">অধ্যায়-৬:রিপভ্যান উইংকল</option>

<option value="অধ্যায়-৭:সাড়ে তিন হাত জমি">অধ্যায়-৭:সাড়ে তিন হাত জমি</option>
</optgroup>

		<?php
	}




if ($subject=='বাংলা দ্বিতীয় পত্র') {
		?>
<option value="">-- SELECT --</option>
<optgroup label="ব্যাকরণ">
<option value="অধ্যায়-১.১:ভাষা">অধ্যায়-১.১:ভাষা</option>
<option value="অধ্যায়-১.২:মাতৃভাষা ও রাষ্ট্রভাষা">অধ্যায়-১.২:মাতৃভাষা ও রাষ্ট্রভাষা</option>
<option value="অধ্যায়-১.৩:সাধু ও চলিত রীতির পার্থক্য">অধ্যায়-১.৩:সাধু ও চলিত রীতির পার্থক্য</option>
<option value="অধ্যায়-২.১:ধ্বনি ও বর্ণ">অধ্যায়-২.১:ধ্বনি ও বর্ণ</option>
<option value="অধ্যায়ন-২.২:ম-ফলা ও ব-ফলার উচ্চারণ">অধ্যায়-২.২:অধ্যায়ন-২.২:ম-ফলা ও ব-ফলার উচ্চারণ</option>
<option value="অধ্যায়-৩.১:সন্ধি">অধ্যায়-৩.১:সন্ধি</option>
<option value="অধ্যায়-৩.২:বিসর্গ সন্ধি">অধ্যায়-৩.২:বিসর্গ সন্ধি</option>
<option value="অধ্যায়-৪:শব্দ ও পদ">অধ্যায়-৪:শব্দ ও পদ</option>
<option value="অধ্যায়-৪.১:লিঙ্গান্তরের নিয়ম ও উদাহরণ">অধ্যায়-৪.১:লিঙ্গান্তরের নিয়ম ও উদাহরণ</option>
<option value="অধ্যায়-৪.২:বহুবচন গঠনের নিয়ম ও উদাহরণ">অধ্যায়-৪.২:বহুবচন গঠনের নিয়ম ও উদাহরণ</option>
<option value="অধ্যায়-৪.৩:বিশেষ্যের শ্রেণিবিভাগ">অধ্যায়-৪.৩:বিশেষ্যের শ্রেণিবিভাগ</option>
<option value="অধ্যায়-৪.৪:নির্দেশক সর্বনামের রূপ">অধ্যায়-৪.৪:নির্দেশক সর্বনামের রূপ"</option>
<option value="অধ্যায়-৪.৫:ধাতু ও ক্রিয়াপদ">অধ্যায়-৪.৫:ধাতু ও ক্রিয়াপদ</option>
<option value="অধ্যায়-৪.৬:সকর্মক ও অকর্মক ক্রিয়া">অধ্যায়-৪.৬:সকর্মক ও অকর্মক ক্রিয়া</option>
<option value="অধ্যায়-৪.৭:মৌলিক ও সাধিত ধাতু">অধ্যায়-৪.৭:মৌলিক ও সাধিত ধাতু</option>
<option value="অধ্যায়-৪.৮:ক্রিয়ার কাল">অধ্যায়-৪.৮:ক্রিয়ার কাল</option>
<option value="অধ্যায়-৫: শব্দগঠন">অধ্যায়-৫: শব্দগঠন</option >
<option value="অধ্যায়-৫.১: ধ্বন্যাত্মক শব্দ, অনুকার শব্দ ও শব্দদ্বৈত">অধ্যায়-৫.১: ধ্বন্যাত্মক শব্দ, অনুকার শব্দ ও শব্দদ্বৈত</option >
<option value="অধ্যায়-৫.২: শব্দগঠন: প্রাথমিক ধারণা ">অধ্যায়-৫.২: শব্দগঠন: প্রাথমিক ধারণা </option>
<option value="অধ্যায়-৬: বাক্য ">অধ্যায়-৬: বাক্য </option>
<option value="অধ্যায়-৬.১:বাক্যগঠনের শর্ত"> অধ্যায়-৬.১:বাক্যগঠনের শর্ত </option>
<option value="অধ্যায়-৬.২: সরল, জটিল ও যৌগিক বাক্যের গঠন">অধ্যায়-৬.২: সরল, জটিল ও যৌগিক বাক্যের গঠন </option>
<option value="অধ্যায়-৭.১: বিরামচিহ্ন ">অধ্যায়-৭.১: বিরামচিহ্ন</option>
<option value="অধ্যায়-৭.২: কমা, সেমিকোলন, কোলন ও হাইফেনের ব্যবহার  ">অধ্যায়-৭.২: কমা, সেমিকোলন, কোলন ও হাইফেনের ব্যবহার</option>
<option value="অধ্যায়-৮: বানান ">অধ্যায়-৮: বানান</option>
<option value="অধ্যায়-৮.১: বানানের কয়েকটি সাধারণ নিয়ম ">অধ্যায়-৮.১: বানানের কয়েকটি সাধারণ নিয়ম</option>
<option value="অধ্যায়-৯: অভিধান ">অধ্যায়-৯: অভিধান</option>
<option value="অধ্যায়-৯.১: বর্ণানুক্রম ">অধ্যায়-৯.১: বর্ণানুক্রম</option>
<option value="অধ্যায়-৯.২: ভুক্তি ও শীর্ষ শব্দ ">অধ্যায়-৯.২ ভুক্তি ও শীর্ষ শব্দ </option>
<option value="অধ্যায়-১০: শব্দার্থ ">অধ্যায়-১০: শব্দার্থ</option>
<option value="অধ্যায়-১০.১: একই শব্দ বিভিন্ন অর্থে প্রয়োগ করে বাক্য রচনা ">অধ্যায়-১০.১: একই শব্দ বিভিন্ন অর্থে প্রয়োগ করে বাক্য রচনা</option>
<option value="অধ্যায়-১০.২: সমার্থক শব্দ প্রয়োগে বাক্য রচনা ">অধ্যায়-১০.২: সমার্থক শব্দ প্রয়োগে বাক্য রচনা </option>
<option value="অধ্যায়-১০.৩: বিপরীতার্থক শব্দ প্রয়োগে বাক্য রচনা ">অধ্যায়-১০.৩: বিপরীতার্থক শব্দ প্রয়োগে বাক্য রচনা </option>
<option value="অধ্যায়-১০.৪: বাগধারা ">অধ্যায়-১০.৪: বাগধারা </option>
</optgroup>
<optgroup label="নির্মিতি">
<option value="অনুধাবন দক্ষতা">অনুধাবন দক্ষতা</option>
<option value="সারমর্ম/সারাংশ">সারমর্ম/সারাংশ</option>
<option value="ভাবসম্প্রসারণ">ভাবসম্প্রসারণ</option>
<option value="আবেদনপত্র ও চিঠি">আবেদনপত্র ও চিঠি</option>
<option value="রচনা">রচনা</option>


</optgroup>


		<?php
	}
if ($subject=='ইংরেজি প্রথম পত্র') {
		?>
<option value="Unit-1:A glimpse of our culture"> Unit-1:A glimpse of our culture </option>

<option value=" Unit-2:Food and Nutrition">Unit-2:Food and Nutrition</option>

<option value="Unit-3:Health and hygiene">Unit-3:Health and hygiene</option>

<option value="Unit-4:Check your reference">Unit-4:Check your reference</option>

<option value="Unit-5:Making a difference">Unit-5:Making a difference </option>

<option value="Unit-6:Going on a foreign trip">Unit-6:Going on a foreign trip </option>

<option value="Unit-7:Different people, different occupations"> Unit-7:Different people, different occupations</option>

<option value="Unit-8:News! News! News!">Unit-8:News! News! News!</option>

<option value="Unit-9:Things that have changed our life">Unit-9:Things that have changed our life</option>

		<?php
}



if ($subject=='ইংরেজি দ্বিতীয় পত্র') {
		?>
<optgroup label="Grammer">
<option value="Unit-1:Parts of Speech">Unit-1:Parts of Speech </option>

<option value="Unit-2:Modals">Unit-2:Modals </option>

<option value="Unit-3:Articles, linking words and Possessives">Unit-3:Articles, linking words and Possessives</option>

<option value="Unit-4:Degree of Adjectives">Unit-4:Degree of Adjectives</option>

<option value="Unit-5:Tenses">Unit-5:Tenses</option>

<option value="Unit-6:Infinitive, Gerund and Participle">Unit-6:Infinitive, Gerund and Participle</option>

<option value="Unit-7:Sentences">Unit-7:Sentences</option>

<option value="Unit-8:Voice">Unit-8:Voice</option>

<option value="Unit-9:Direct and Indirect Speech"> Unit-9:Direct and Indirect Speech</option>

<option value="Unit-10:Suffixes and Prefixes">Unit-10:Suffixes and Prefixes</option>

<option value="Unit-11:Capitalization and Punctuation">Unit-11:Capitalization and Punctuation </option>


</optgroup>
<optgroup label="Composition">
<option value="Writing Proccess">Writing Proccess </option>
<option value="Letter writing">Letter writing </option>
<option value="Writing email">Writing email </option>
<option value="Developing Composition">Developing Composition</option>
</optgroup>
		<?php
	}





if ($subject=='গনিত') {
		?>
<option value="অধ্যায়-১:প্যাটার্ন"> অধ্যায়-১:প্যাটার্ন</option>

<option value="অধ্যায়-২:মুনাফা"> অধ্যায়-২:মুনাফা</option>

<option value="অধ্যায়-৩:পরিমাপ"> অধ্যায়-৩:পরিমাপ </option>

<option value="অধ্যায়-৪:বীজগণিতীয় সূত্রাবলি ও প্রয়ােগ"> অধ্যায়-৪:বীজগণিতীয় সূত্রাবলি ও প্রয়ােগ </option>

<option value="অধ্যায়-৫:বীজগণিতীয় ভগ্নাংশ"> অধ্যায়-৫:বীজগণিতীয় ভগ্নাংশ </option>

<option value="অধ্যায়-৬:সরল সহসমীকরণ"> অধ্যায়-৬:সরল সহসমীকরণ </option>

<option value="অধ্যায়-৭:সেট"> অধ্যায়-৭:সেট</option>
<option value="অধ্যায়-৮:চতুর্ভুজ"> অধ্যায়-৮:চতুর্ভুজ</option>

<option value="অধ্যায়-৯:পিথাগোরাসের উপপাদ্য"> অধ্যায়-৯:পিথাগোরাসের উপপাদ্য </option>

<option value="অধ্যায়-১০:বৃত্ত"> অধ্যায়-১০:বৃত্ত</option>

<option value="অধ্যায়-১১:তথ্য ও উপাত্ত"> অধ্যায়-১১:তথ্য ও উপাত্ত </option>

		<?php
	}


	

if ($subject=='সাধারণ বিজ্ঞান') {
		?>
<option value="অধ্যায়-১:প্রাণিজগতের শ্রেণিবিন্যাস"> অধ্যায়-১:প্রাণিজগতের শ্রেণিবিন্যাস</option>

<option value="অধ্যায়-২:জীবের বৃদ্ধি ও বংশগতি">  অধ্যায়-২:জীবের বৃদ্ধি ও বংশগতি</option>

<option value="অধ্যায়-৩:ব্যাপন, অভিস্রবণ ও প্রস্বেদন"> অধ্যায়-৩:ব্যাপন, অভিস্রবণ ও প্রস্বেদন</option>


<option value="অধ্যায়-৪:উদ্ভিদের বংশ বৃদ্ধি"> অধ্যায়-৪:উদ্ভিদের বংশ বৃদ্ধি</option>

<option value="অধ্যায়-৫:সমন্বয় ও নিঃসরণ"> অধ্যায়-৫:সমন্বয় ও নিঃসরণ</option>

<option value="অধ্যায়-৬:পরমাণুর গঠন"> অধ্যায়-৬:পরমাণুর গঠন </option>

<option value="অধ্যায়-৭:পৃথিবী ও মহাকর্ষ"> অধ্যায়-৭:পৃথিবী ও মহাকর্ষ</option>

<option value="অধ্যায়-৮:রাসায়নিক বিক্রিয়া"> অধ্যায়-৮:রাসায়নিক বিক্রিয়া</option>

<option value="অধ্যায়-৯:বর্তনী ও চলবিদ্যুৎ"> অধ্যায়-৯:বর্তনী ও চলবিদ্যুৎ</option>

<option value="অধ্যায়-১০:অম্ল, ক্ষারক ও লবণ"> অধ্যায়-১০:অম্ল, ক্ষারক ও লবণ</option>

<option value="অধ্যায়-১১:আলো"> অধ্যায়-১১:আলো </option>

<option value="অধ্যায়-১২:মহাকাশ ও উপগ্রহ">অধ্যায়-১২: মহাকাশ ও উপগ্রহ</option>

<option value="অধ্যায়-১৩:খাদ্য ও পুষ্টি"> অধ্যায়-১৩:খাদ্য ও পুষ্টি</option>

<option value="অধ্যায়-১৪:পরিবেশ ও বাস্তুতন্ত্র "> অধ্যায়-১৪:পরিবেশ ও বাস্তুতন্ত্র </option>

		<?php
	}


if ($subject=='বাংলাদেশ ও বিশ্ব পরিচয়') {
		?>

<option value="অধ্যায়-১:ঔপনিবেশিক যুগ ও বাংলার স্বাধীনতা সংগ্রাম"> অধ্যায়-১:ঔপনিবেশিক যুগ ও বাংলার স্বাধীনতা সংগ্রাম </option>

<option value="অধ্যায়-২:বাংলাদেশের মুক্তিযুদ্ধ"> অধ্যায়-২:বাংলাদেশের মুক্তিযুদ্ধ</option>

<option value="অধ্যায়-৩:বাংলাদেশের সাংস্কৃতিক পরিবর্তন ও উন্নয়ন"> অধ্যায়-৩:বাংলাদেশের সাংস্কৃতিক পরিবর্তন ও উন্নয়ন </option>

<option value="অধ্যায়-৪:ঔপনিবেশিক যুগের প্রত্নতাত্ত্বিক ঐতিহ্য">অধ্যায়-৪:ঔপনিবেশিক যুগের প্রত্নতাত্ত্বিক ঐতিহ্য</option>

<option value="অধ্যায়-৫:সামাজিকীকরণ ও উন্নয়ন"> অধ্যায়-৫:সামাজিকীকরণ ও উন্নয়ন</option>
<option value="অধ্যায়-৬:বাংলাদেশের অর্থনীতি"> অধ্যায়-৬:বাংলাদেশের অর্থনীতি </option>
<option value="অধ্যায়-৭:বাংলাদেশের : রাষ্ট্র ও সরকার ব্যবস্থা"> অধ্যায়-৭:বাংলাদেশের : রাষ্ট্র ও সরকার ব্যবস্থা </option>

<option value="অধ্যায়-৮:বাংলাদেশের দুর্যোগ"> অধ্যায়-৮:বাংলাদেশের দুর্যোগ</option>

<option value="অধ্যায়-৯:বাংলাদেশের জনসংখ্যা ও উন্নয়ন"> অধ্যায়-৯:বাংলাদেশের জনসংখ্যা ও উন্নয়ন</option>

<option value="অধ্যায়-১০:বাংলাদেশের সামাজিক সমস্যা"> অধ্যায়-১০:বাংলাদেশের সামাজিক সমস্যা </option>

<option value="অধ্যায়-১১:বাংলাদেশের বিভিন্ন নৃগোষ্টি"> অধ্যায়-১১:বাংলাদেশের বিভিন্ন নৃগোষ্টি</option>

<option value="অধ্যায়-১২:বাংলাদেশের প্রাকৃতিক সম্পদ"> অধ্যায়-১২:বাংলাদেশের প্রাকৃতিক সম্পদ</option>

<option value="অধ্যায়-১৩:বাংলাদেশ এবং বিভিন্ন আন্তর্জাতিক ও আঞ্চলিক সহযোগী  সংস্থা"> অধ্যায়-১৩:বাংলাদেশ এবং বিভিন্ন আন্তর্জাতিক ও আঞ্চলিক সহযোগী  সংস্থা</option>
<option value="অধ্যায়-১৪:টেকসই উন্নয়ন অভীষ্ট (এসডিজি)"> অধ্যায়-১৪:টেকসই উন্নয়ন অভীষ্ট (এসডিজি)  </option>


		<?php
	}
	

if ($subject=='কৃষিশিক্ষা') {
		?>
<option value="অধ্যায়-১:বাংলাদেশের কৃষি ও আন্তর্জাতিক প্রেক্ষাপট">  অধ্যায়-১:বাংলাদেশের কৃষি ও আন্তর্জাতিক প্রেক্ষাপট </option>

<option value="অধ্যায়-২:কৃষি প্রযুক্তি"> অধ্যায়-২:কৃষি প্রযুক্তি </option>


<option value="অধ্যায়-৩:কৃষি উপকরণ"> অধ্যায়-৩:কৃষি উপকরণ </option>

<option value="অধ্যায়-৪:কৃষি ও জলবায়ু"> অধ্যায়-৪:কৃষি ও জলবায়ু </option>


<option value="অধ্যায়-৫:কৃষিজ উৎপাদন"> অধ্যায়-৫:কৃষিজ উৎপাদন </option>

<option value="অধ্যায়-৬:বনায়ন"> অধ্যায়-৬:বনায়ন </option>

		<?php
	}	








if ($subject=='তথ্য ও যোগাযোগ প্রযুক্তি') {
		?>
<option value="অধ্যায়-১: তথ্য ও যোগাযোগ প্রযুক্তির গুরুত্ব">  অধ্যায়-১: তথ্য ও যোগাযোগ প্রযুক্তির গুরুত্ব</option>

<option value="অধ্যায়-২: কম্পিউটার নেটওয়ার্ক"> অধ্যায়-২: কম্পিউটার নেটওয়ার্ক</option>


<option value="অধ্যায়-৩: তথ্য ও যোগাযোগ প্রযুক্তির নিরাপদ ও নৈতিক ব্যবহার"> অধ্যায়-৩: তথ্য ও যোগাযোগ প্রযুক্তির নিরাপদ ও নৈতিক ব্যবহার</option>

<option value="অধ্যায়-৪:স্প্রেডশিটের ব্যবহার"> অধ্যায়-৪:স্প্রেডশিটের ব্যবহার</option>


<option value="অধ্যায়-৫:শিক্ষা ও দৈনন্দিন জীবনে ইন্টারনেটের ব্যবহার"> অধ্যায়-৫:শিক্ষা ও দৈনন্দিন জীবনে ইন্টারনেটের ব্যবহার</option>

		<?php
	}







if ($subject=='ইসলাম ও নৈতিক শিক্ষা') {
		?>
<option value="অধ্যায়-১:আকাইদ"> অধ্যায়-১:আকাইদ </option>

<option value="অধ্যায়-২:ইবাদত"> অধ্যায়-২:ইবাদত </option>

<option value="অধ্যায়-৩:কুরআন ও হাদিস শিক্ষা"> অধ্যায়-৩:কুরআন ও হাদিস শিক্ষা </option>

<option value="অধ্যায়-৪:আখলাক"> অধ্যায়-৪:আখলাক </option>

<option value="অধ্যায়-৫:আদর্শ জীবনচরিত"> অধ্যায়-৫:আদর্শ জীবনচরিত </option>

		<?php
	}





if ($subject=='হিন্দু ধর্ম ও নৈতিক শিক্ষা') {
		?>
<option value="অধ্যায়-১:ঈশ্বরের স্বরূপ"> অধ্যায়-১:ঈশ্বরের স্বরূপ </option>

<option value="অধ্যায়-২:ধর্মগ্রন্থ"> অধ্যায়-২:ধর্মগ্রন্থ </option>

<option value="অধ্যায়-৩: হিন্দুধর্মের স্বরূপ ও বিশ্বাস"> অধ্যায়-৩: হিন্দুধর্মের স্বরূপ ও বিশ্বাস </option>

<option value="অধ্যায়-৪:নিত্যকর্ম ও যােগাসন"> অধ্যায়-৪:নিত্যকর্ম ও যােগাসন </option>

<option value="অধ্যায়-৫:দেব-দেবী ও পূজা-পার্বণ"> অধ্যায়-৫:দেব-দেবী ও পূজা-পার্বণ </option>

<option value="অধ্যায়-৬:ধর্মীয় উপাখ্যানে নৈতিক শিক্ষা"> অধ্যায়-৬:ধর্মীয় উপাখ্যানে নৈতিক শিক্ষা </option>

<option value="অধ্যায়-৭:আদর্শ জীবনচরিত"> অধ্যায়-৭:আদর্শ জীবনচরিত </option>

<option value="অধ্যায়-৮:হিন্দুধর্ম ও নৈতিক মূল্যবোেধ"> অধ্যায়-৮:হিন্দুধর্ম ও নৈতিক মূল্যবোধ </option>

		<?php
	}




if ($subject=='বৌদ্ধ ধর্ম ও নৈতিক শিক্ষা') {
		?>
<option value="অধ্যায়-১:গৌতম বুদ্ধের সাম্যনীতি"> অধ্যায়-১:গৌতম বুদ্ধের সাম্যনীতি<option>

<option value="অধ্যায়-২:বন্দনা"> অধ্যায়-২:বন্দনা <option>

<option value="অধ্যায়-৩:শীল"> অধ্যায়-৩:শীল <option>

<option value="অধ্যায়-৪:দান"> অধ্যায়-৪:দান <option>

<option value="অধ্যায়-৫:সূত্র ও নীতিগাথা"> অধ্যায়-৫:সূত্র ও নীতিগাথা <option>

<option value="অধ্যায়-৬:পারমী"> অধ্যায়-৬:পারমী<option>

<option value="অধ্যায়-৭:ধর্মীয় আচার-অনুষ্ঠান ও উৎসব"> অধ্যায়-৭:ধর্মীয় আচার-অনুষ্ঠান ও উৎসব <option>

<option value="অধ্যায়-৮:চরিতমালা"> অধ্যায়-৮:চরিতমালা <option>

<option value="অধ্যায়-৯:জাতক"> অধ্যায়-৯:জাতক <option>

<option value="অধ্যায়-১০:বৌদ্ধ তীর্থস্থান"> অধ্যায়-১০:বৌদ্ধ তীর্থস্থান <option>

<option value="অধ্যায়-১১:বৌদ্ধধর্মে রাজন্যবর্গের অবদান: সম্রাট কণিঙ্ক"> অধ্যায়-১১:বৌদ্ধধর্মে রাজন্যবর্গের অবদান: সম্রাট কণিঙ্ক<option> 

		<?php
	}



if ($subject=='খ্রিস্টান ধর্ম ও নৈতিক শিক্ষা') {
		?>
<option value="অধ্যায়-১: পবিত্র আত্মা"> অধ্যায়-১: পবিত্র আত্মা</option>

<option value="অধ্যায়-২: ঈশ্বরের সৃষ্টির লালন"> অধ্যায়-২: ঈশ্বরের সৃষ্টির লালন </option>


<option value="অধ্যায়-৩:ঈশ্বর ও মানুষ"> অধ্যায়-৩:ঈশ্বর ও মানুষ </option>

<option value="অধ্যায়-৪:মানুষের পতনের ফল"> অধ্যায়-৪:মানুষের পতনের ফল </option>


<option value="অধ্যায়-৫:যীশুর বানী প্রচারের মূলভাব">  অধ্যায়-৫:যীশুর বানী প্রচারের মূলভাব</option>

<option value="অধ্যায়-৬: যীশুর আহ্বানে পিতরের সাড়াদান">  অধ্যায়-৬: যীশুর আহ্বানে পিতরের সাড়াদান </option>

<option value="অধ্যায়-৭:যীশুর আশ্চর্য কাজ ও ঐশরাজ্য">  অধ্যায়-৭:যীশুর আশ্চর্য কাজ ও ঐশরাজ্য </option>


<option value="অধ্যায়-৮:খ্রিষ্টমণ্ডলী"> অধ্যায়-৮:খ্রিষ্টমণ্ডলী</option>


<option value="অধ্যায়-৯: ন্যায্যতা, শান্তি ও আত্মসংযম"> অধ্যায়-৯: ন্যায্যতা, শান্তি ও আত্মসংযম</option>


<option value="অধ্যায়-১০: ঈশ্বরের সেবক থিওটোনিয়াস অমল গাঙ্গুলী"> অধ্যায়-১০: ঈশ্বরের সেবক থিওটোনিয়াস অমল গাঙ্গুলী</optin>

	<?php
	}


if ($subject=='চারু ও কারু কলা') {
		?>
<option value="অধ্যায়-১:বাংলাদেশের প্রাচীন শিল্পকলা ও ঐতিহ্যের পরিচয়"> অধ্যায়-২:বাংলাদেশের প্রাচীন শিল্পকলা ও ঐতিহ্যের পরিচয়</option>

<option value="অধ্যায়-২:বাংলাদেশের অভ্যুদয়ে চারুশিল্প ও শিল্পীরা"> অধ্যায়-২:বাংলাদেশের অভ্যুদয়ে চারুশিল্প ও শিল্পীরা</option>

<option value="অধ্যায়-৩: বিখ্যাত শিল্পী ও শিল্পকর্ম"> অধ্যায়-৩: বিখ্যাত শিল্পী ও শিল্পকর্ম</option>

<option value="অধ্যায়-৪:শিল্পকলা"> অধ্যায়-৪:শিল্পকলা</option>

<option value="অধ্যায়-৫:ছবি আঁকার বিভিন্ন মাধ্যম ও উপকরণ"> অধ্যায়-৫:ছবি আঁকার বিভিন্ন মাধ্যম ও উপকরণ</option>

<option value="অধ্যায়-৬:বিষয়ভিত্তিক ছবি ও নকশা অঙ্কন"> অধ্যায়-৬:বিষয়ভিত্তিক ছবি ও নকশা অঙ্কন</option>

<option value="অধ্যায়-৭: বিভিন্ন মাধ্যমের শিল্পকর্ম"> অধ্যায়-৭: বিভিন্ন মাধ্যমের শিল্পকর্ম</option>

	<?php
	}

if ($subject=='কর্ম ও জীবনমুখী শিক্ষা') {
		?>
<option value="অধ্যায়-১:মেধা, কায়িকশ্রম ও আত্ম-অনুসন্ধান"> অধ্যায়-১:মেধা, কায়িকশ্রম ও আত্ম-অনুসন্ধান</option>

<option value="অধ্যায়-২:আমাদের কাজ : যেগুলো অন্যেরা করে"> অধ্যায়-২:আমাদের কাজ : যেগুলো অন্যেরা করে</option>

<option value="অধ্যায়-৩:আমাদের শিক্ষা ও কর্ম">  অধ্যায়-৩:আমাদের শিক্ষা ও কর্ম</option>


	<?php
	}
if ($subject=='শারীরিক শিক্ষা') {
		?>
<option value="অধ্যায়-১:শরীরচর্চা ও সুস্থজীবন"> অধ্যায়-১:শরীরচর্চা ও সুস্থজীবন </option>

<option value="অধ্যায়-২:স্কাউটিং ও গার্ল গাইডিং ও বাংলাদেশ রেড ক্রিসেন্ট সোসাইটি"> অধ্যায়-২:স্কাউটিং ও গার্ল গাইডিং  ও বাংলাদেশ রেড ক্রিসেন্ট সোসাইটি</option>

<option value="অধ্যায়-৩:স্বাস্থ্যবিজ্ঞান পরিচিতি ও স্বাস্থ্যসেবা"> অধ্যায়-৩:স্বাস্থ্যবিজ্ঞান পরিচিতি ও স্বাস্থ্যসেবা </option>

<option value="অধ্যায়-৪:আমাদের জীবনে প্রজনন স্বাস্থ্য"> অধ্যায়-৪:আমাদের জীবনে প্রজনন স্বাস্থ্য</option>

<option value="অধ্যায়-৫:জীবনের জন্য খেলাধুলা"> অধ্যায়-৫:জীবনের জন্য খেলাধুলা</option>

	<?php
	}


if ($subject=='গার্হস্থ্য বিজ্ঞান') {
		?>
<optgroup label="ক বিভাগ: গৃহ ব্যবস্থাপনা ও গৃহ সম্পদ">

<option value="অধ্যায়-১:গৃহ সম্পদের সুষ্ঠু ব্যবহার">  অধ্যায়-১:গৃহ সম্পদের সুষ্ঠু ব্যবহার </optin>

<option value="অধ্যায়-২: গৃহ পরিবেশে নিরাপত্তা">  অধ্যায়-২: গৃহ পরিবেশে নিরাপত্তা</optin>

<option value="অধ্যায়-৩: গৃহে রোগীর শুশ্রূষা">  অধ্যায়-৩:গৃহে রোগীর শুশ্রূষা</optin>


</optgroup>

<optgroup label="খ বিভাগ: শিশুবিকাশ ও ব্যক্তিগত নিরাপত্তা">
	
<option value="অধ্যায়-৪:বয়সন্ধিকাল"> অধ্যায়-৪:বয়সন্ধিকাল</optin>

<option value="অধ্যায়-৫:রোগ সম্পর্কে সতর্কতা"> অধ্যায়-৫:রোগ সম্পর্কে সতর্কতা</optin>

<option value="অধ্যায়-৬:বিশেষ চাহিদা সম্পন্ন শিশু"> অধ্যায়-৬:বিশেষ চাহিদা সম্পন্ন শিশু</optin>

<option value="অধ্যায়-৭:বিভিন্ন প্রতিকূল অবস্থা থেকে নিজেকে রক্ষা করা"> অধ্যায়-৭:বিভিন্ন প্রতিকূল অবস্থা থেকে নিজেকে রক্ষা করা</optin>

</optgroup>
<optgroup label="গ-বিভাগ: খাদ্য ও পুস্টি ব্যবস্থপনা">

<option value="অধ্যায়-৮:খাদ্য পরিকল্পনা"> অধ্যায়-৮:খাদ্য পরিকল্পনা</optin>

<option value="অধ্যায়-৯:অপুষ্টি"> অধ্যায়-৯:অপুষ্টি</optin>

<option value="অধ্যায়-১০:পরিবারের  জন্য খাদ্য নির্বাচন, ক্রয় ও প্রস্তুতে সতর্কতা"> অধ্যায়-১০:পরিবারের  জন্য খাদ্য নির্বাচন, ক্রয় ও প্রস্তুতে সতর্কতা</optin>

<option value="অধ্যায়-১১:খাদ্য রান্না"> অধ্যায়-১১:খাদ্য রান্না </optin>

</optgroup>

<optgroup label="ঘ-বিভাগ: পোশাক-পরিচ্ছদ ও বস্ত্র">
<option value="অধ্যায়-১২:সুতা তৈরি ও বুনন"> অধ্যায়-১২:সুতা তৈরি ও বুনন</optin>
<option value="অধ্যায়-১৩:পোশাক নির্বাচনে বিবেচ্য বিষয়"> অধ্যায়-১৩:পোশাক নির্বাচনে বিবেচ্য বিষয়</optin>
<option value="অধ্যায়-১৪:পোশাক ক্রয়ে বিবেচ্য বিষয়"> অধ্যায়-১৪:পোশাক নির্বাচনে ক্রয়ে বিষয়</optin>
<option value="অধ্যায়-১৫:পোশাক তৈরি"> অধ্যায়-১৫:পোশাক তৈরি</optin>
</optgroup>
	<?php
	}
}

if ($class==9 || $class==10) {
	if ($subject=='বাংলা প্রথম পত্র') {
		?>
<optgroup label="গদ্য">
	<option value="অধ্যায়-১: প্রত্যুপকার">অধ্যায়-১: প্রত্যুপকার</option>
	<option value="অধ্যায়-২: ফুলের বিবাহসুভা">অধ্যায়-২: ফুলের বিবাহসুভা</option>
	<option value="অধ্যায়-৩: সুভা">অধ্যায়-৩: সুভা</option>
	<option value="অধ্যায়-৪: লাইব্রেরি">অধ্যায়-৪: লাইব্রেরি</option>
	<option value="অধ্যায়-৫: দেনাপাওনা">অধ্যায়-৫: দেনাপাওনা</option>
	<option value="অধ্যায়-৬: বই পড়া">অধ্যায়-৬: বই পড়া</option>
	<option value="অধ্যায়-৭: অভাগীর স্বর্গ">অধ্যায়-৭: অভাগীর স্বর্গ</option>
	<option value="অধ্যায়-৮: নিরীহ বাঙালি">অধ্যায়-৮: নিরীহ বাঙালি</option>
	<option value="অধ্যায়-৯: পল্লিসাহিত্য">অধ্যায়-৯: পল্লিসাহিত্য</option>
	<option value="অধ্যায়-১০: উদ্যম ও পরিশ্রম">অধ্যায়-১০: উদ্যম ও পরিশ্রম</option>
	<option value="অধ্যায়-১১: জীবনে শিল্পের স্থান">অধ্যায়-১১: জীবনে শিল্পের স্থান</option>
	<option value="অধ্যায়-১২: আম-আঁটির ভেঁপু">অধ্যায়-১২: আম-আঁটির ভেঁপু</option>
	<option value="অধ্যায়-১৩: মানুষ মুহম্মদ (সঃ)">অধ্যায়-১৩: মানুষ মুহম্মদ (সঃ)</option>
	<option value="অধ্যায়-১৪: নিমগাছ">অধ্যায়-১৪: নিমগাছ</option>
	<option value="অধ্যায়-১৫: উপেক্ষিত শক্তির উদ্বোধন">অধ্যায়-১৫: উপেক্ষিত শক্তির উদ্বোধন</option>
	<option value="অধ্যায়-১৬: শিক্ষা ও মনুষ্যত্ব">অধ্যায়-১৬: শিক্ষা ও মনুষ্যত্ব</option>
	<option value="অধ্যায়-১৭: লাইব্রেরি">অধ্যায়-১৭: লাইব্রেরি</option>
	<option value="অধ্যায়-১৮: প্রবাস বন্ধু">অধ্যায়-১৮: প্রবাস বন্ধু</option>
	<option value="অধ্যায়-১৯: মমতাদি">অধ্যায়-১৯: মমতাদি</option>
	<option value="অধ্যায়-২০: রহমানের মা">অধ্যায়-২০: রহমানের মা</option>
	<option value="অধ্যায়-২১: পয়লা বৈশাখ">অধ্যায়-২১: পয়লা বৈশাখ</option>
	<option value="অধ্যায়-২২: বনমানুষ">অধ্যায়-২২: বনমানুষ</option>
	<option value="অধ্যায়-২৩: একাত্তরের দিনগুলি">অধ্যায়-২৩: একাত্তরের দিনগুলি</option>
	<option value="অধ্যায়-২৪: স্বাধীনতা আমার স্বাধীনতা">অধ্যায়-২৪: স্বাধীনতা আমার স্বাধীনতা</option>
	<option value="অধ্যায়-২৫: বাঁধ">অধ্যায়-২৫: বাঁধ</option>
	<option value="অধ্যায়-২৬: আমাদের সংস্কৃতি">অধ্যায়-২৬: আমাদের সংস্কৃতি</option>
	<option value="অধ্যায়-২৭: সাহিত্যের রূপ ও রীতি">অধ্যায়-২৭: সাহিত্যের রূপ ও রীতি</option>
	<option value="অধ্যায়-২৮: বাঙলা শব্দ">অধ্যায়-২৮: বাঙলা শব্দ</option>
	<option value="অধ্যায়-২৯: রক্তে ভেজা একুশ">অধ্যায়-২৯: রক্তে ভেজা একুশ</option>
	<option value="অধ্যায়-৩০: নিয়তি">অধ্যায়-৩০: নিয়তি</option>
	<option value="অধ্যায়-৩১: তথ্য প্রযুক্তি">অধ্যায়-৩১: তথ্য প্রযুক্তি</option>
	
</optgroup>

<optgroup label="কবিতা" >
	
	<option value="অধ্যায়-১: বন্দনা">অধ্যায়-১: বন্দনা</option>
	<option value="অধ্যায়-২: হাম্দ্">অধ্যায়-২: হাম্দ্</option>
	<option value="অধ্যায়-৩: বঙ্গবাণী">অধ্যায়-৩: বঙ্গবাণী</option>
	<option value="অধ্যায়-৪: কপোতাক্ষ নদ">অধ্যায়-৪: কপোতাক্ষ নদ</option>
	<option value="অধ্যায়-৫: জীবন-সঙ্গীত">অধ্যায়-৫: জীবন-সঙ্গীত</option>
	<option value="অধ্যায়-৬: প্রাণ">অধ্যায়-৬: প্রাণ</option>
	<option value="অধ্যায়-৭: জুতা-আবিষ্কার">অধ্যায়-৭: জুতা-আবিষ্কার</option>
	<option value="অধ্যায়-৮: অন্ধবধূ">অধ্যায়-৮: অন্ধবধূ</option>
	<option value="অধ্যায়-৯: ঝর্ণার গান">অধ্যায়-৯: ঝর্ণার গান</option>
	<option value="অধ্যায়-১০: ছায়াবাজি">অধ্যায়-১০: ছায়াবাজি</option>
	<option value="অধ্যায়-১১: জীবন বিনিময়">অধ্যায়-১১: জীবন বিনিময়</option>
	<option value="অধ্যায়-১২: আজ সৃষ্টি-সুখের উল্লাসে">অধ্যায়-১২: আজ সৃষ্টি সুখের উল্লাসে</option>
	<option value="অধ্যায়-১৩: মানুষ">অধ্যায়-১৩: মানুষ</option>
	<option value="অধ্যায়-১৪: উমর ফারুখ">অধ্যায়-১৪: উমর ফারুখ</option>
	<option value="অধ্যায়-১৫: সেইদিন এই মাঠ">অধ্যায়-১৫: সেইদিন এই মাঠ</option>
	<option value="অধ্যায়-১৬: পল্লিজননী">অধ্যায়-১৬: পল্লিজননী</option>
	<option value="অধ্যায়-১৭: একটি কাফি">অধ্যায়-১৭: একটি কাফি</option>
	<option value="অধ্যায়-১৮: আমার দেশ">অধ্যায়-১৮: আমার দেশ</option>
	<option value="অধ্যায়-১৯: আশা">অধ্যায়-১৯: আশা</option>
	<option value="অধ্যায়-২০: বৃষ্টি">অধ্যায়-২০: বৃষ্টি</option>
	<option value="অধ্যায়-২১: আমি কোন আগুন্তক নই">অধ্যায়-২১: আমি কোন আগুন্তক নই</option>
	<option value="অধ্যায়-২২: মে-দিনের কবিতা">অধ্যায়-২২: মে-দিনের কবিতা</option>
	<option value="অধ্যায়-২৩: পোস্টার">অধ্যায়-২৩: পোস্টার</option>
	<option value="অধ্যায়-২৪: রানার">অধ্যায়-২৪: রানার</option>
	<option value="অধ্যায়-২৫: তোমাকে পাওয়ার জন্য, হে স্বাধীনতা">অধ্যায়-২৫: তোমাকে পাওয়ার জন্য, হে স্বাধীনতা</option>
	<option value="অধ্যায়-২৬: অবাক সূর্যোদয়">অধ্যায়-২৬: অবাক সূর্যোদয়</option>
	<option value="অধ্যায়-২৭: আমার পরিচয়">অধ্যায়-২৭: আমার পরিচয়</option>
	<option value="অধ্যায়-২৮: বোশেখ">অধ্যায়-২৮: বোশেখ</option>
	<option value="অধ্যায়-২৯: চুনিয়া আমার আর্কেডিয়া">অধ্যায়-২৯: চুনিয়া আমার আর্কেডিয়া</option>
	<option value="অধ্যায়-৩০: স্বাধীনতা, এ শব্দটি কীভাবে আমাদের হলো">অধ্যায়-৩০: স্বাধীনতা, এ শব্দটি কীভাবে আমাদের হলো</option>
	<option value="অধ্যায়-৩১: সাহসী জননী বাংলা">অধ্যায়-৩১: সাহসী জননী বাংলা</option>
	<option value="অধ্যায়-৩২: মিছিল">অধ্যায়-৩২: মিছিল</option>

</optgroup>
<optgroup label="আনন্দপাঠ">
	<option value="অধ্যায়-১:কিশোর কাজি">অধ্যায়-১:কিশোর কাজি</option>
	<option value="অধ্যায়-২:রাজকুমার ও ভিখারির ছেলে">অধ্যায়-২:রাজকুমার ও ভিখারির ছেলে</option>
	<option value="অধ্যায়-৩:রবিন্সন ক্রুসো">অধ্যায়-৩:রবিন্সন ক্রুসো</option>
	<option value="অধ্যায়-৪:সোহরাব রুস্তম">অধ্যায়-৪:সোহরাব রুস্তম</option>
	<option value="অধ্যায়-৫:মার্চেন্ট অব ভেনিস">অধ্যায়-৫:মার্চেন্ট অব ভেনিস</option>
	<option value="অধ্যায়-৬:রিপভ্যান উইংকল">অধ্যায়-৬:রিপভ্যান উইংকল</option>
	<option value="অধ্যায়-৭:সাড়ে তিন হাত জমি">অধ্যায়-৭:সাড়ে তিন হাত জমি</option>
</optgroup>
		<?php
	}

	if ($subject=='বাংলা দ্বিতীয় পত্র') {
		?>
<optgroup label="ব্যাকরণ">
	<option value="অধ্যায়-১">অধ্যায়-১</option>
	<option value="অধ্যায়-২">অধ্যায়-২</option>
	<option value="অধ্যায়-৩">অধ্যায়-৩</option>
	<option value="অধ্যায়-৪">অধ্যায়-৪</option>
	<option value="অধ্যায়-৫">অধ্যায়-৫</option>
</optgroup>

<optgroup label="রচনা সম্ভার" >
	<option value="বিরচন">বিরচন</option>
	<option value="প্রবন্ধ রচনা">প্রবন্ধ রচনা</option>
</optgroup>

		<?php
	}
	if ($subject=='ইংরেজি প্রথম পত্র') {
		?>
	<option value="Unit-01: Good citizens">Unit-01: Good citizens</option>
	<option value="Unit-02: Pastimes">Unit-02: Pastimes</option>
	<option value="Unit-03: Events and festivals">Unit-03: Events and festivals</option>
	<option value="Unit-04: Are you aware?">Unit-04: Are you aware?</option>
	<option value="Unit-05: Nature and environment">Unit-05: Nature and environment</option>
	<option value="Unit-06: Our neighbours">Unit-06: Our neighbours</option>
	<option value="Unit-07: People who stand out">Unit-07: People who stand out</option>
	<option value="Unit-08: World heritage">Unit-08: World heritage</option>
	<option value="Unit-09: Unconventional jobs">Unit-09: Unconventional jobs</option>
	<option value="Unit-10: Dreams">Unit-10: Dreams</option>
	<option value="Unit-11: Renewable energy">Unit-11: Renewable energy</option>
	<option value="Unit-12: Roots">Unit-12: Roots</option>
	<option value="Unit-13: Media and modes of e-communication">Unit-13: Media and modes of e-communication</option>
	<option value="Unit-14: Pleasure and purpose">Unit-14: Pleasure and purpose</option>
	


		<?php
	}

	if ($subject=='ইংরেজি দ্বিতীয় পত্র') {
		?>
		<optgroup label="Grammar">
	<option value="Unit-01: The Noun">Unit-01: The Noun</option>
	<option value="Unit-02: Pronouns and Possessives">Unit-02: Pronouns and Possessives</option>
	<option value="Unit-03: Adjectives">Unit-03: Adjectives</option>
	<option value="Unit-04: Verbs and Tenses">Unit-04: Verbs and Tenses</option>
	<option value="Unit-05: Verbs: Modals">Unit-05: Verbs: Modals</option>
	<option value="Unit-06: Kinds of Verbs">Unit-06: Kinds of Verbs</option>
	<option value="Unit-07: The Adverb">Unit-07: The Adverb</option>
	<option value="Unit-08: The Preposition">Unit-08: The Preposition</option>
	<option value="Unit-09: Sentences">Unit-09: Sentences</option>
	<option value="Unit-10: Introductory 'it' & 'there'">Unit-10: Introductory 'it' & 'there'</option>
	<option value="Unit-11: Conditionals">Unit-11: Conditionals</option>
	<option value="Unit-12: The Passive">Unit-12: The Passive</option>
	<option value="Unit-13: Speech">Unit-13: Speech</option>

		</optgroup>
	

<optgroup label="Composition">
	<option value="Unit-14: Letters">Unit-01: Letters</option>
	<option value="Unit-15: CV & Cover Letter">Unit-02: CV & Cover Letter</option>
	<option value="Unit-16: E-mails">Unit-03: E-mails</option>
	<option value="Unit-17: Short Composition: Paragraphs">Unit-04: Short Composition: Paragraphs</option>
	<option value="Unit-18: Short Composition">Unit-05: Short Composition</option>
	<option value="Unit-19: Completing Stories">Unit-06: Completing Stories</option>
	<option value="Unit-20: Writing Summaries">Unit-07: Writing Summaries</option>
	<option value="Unit-21: Describing Graphs and Charts">Unit-08: Describing Graphs and Charts</option>
		</optgroup>


		<?php
	}
	if ($subject=='গনিত') {
	?>
	<!-- <option value="অধ্যায়-১: ">অধ্যায়-১: </option>
	<option value="অধ্যায়-২: ">অধ্যায়-২: </option>
	<option value="অধ্যায়-৩: ">অধ্যায়-৩: </option>
	<option value="অধ্যায়-৪: ">অধ্যায়-৪: </option>
	<option value="অধ্যায়-৫: ">অধ্যায়-৫: </option>
	<option value="অধ্যায়-৬: ">অধ্যায়-৬: </option>
	<option value="অধ্যায়-৭: ">অধ্যায়-৭: </option>
	<option value="অধ্যায়-৮: ">অধ্যায়-৮: </option>
	<option value="অধ্যায়-৯: ">অধ্যায়-৯: </option>
	<option value="অধ্যায়-১০: ">অধ্যায়-১০: </option>
	<option value="অধ্যায়-১১: ">অধ্যায়-১১: </option>
	<option value="অধ্যায়-১২: ">অধ্যায়-১২: </option>
	<option value="অধ্যায়-১৩: ">অধ্যায়-১৩: </option>
	<option value="অধ্যায়-১৪: ">অধ্যায়-১৪: </option>
	<option value="অধ্যায়-১৫: ">অধ্যায়-১৫: </option>
	<option value="অধ্যায়-১৬: ">অধ্যায়-১৬: </option>
	<option value="অধ্যায়-১৭: ">অধ্যায়-১৭: </option> -->
	<option value="অধ্যায়-১: বাস্তব সংখ্যা">অধ্যায়-১: বাস্তব সংখ্যা</option>
	<option value="অধ্যায়-২: সেট ও ফাংশন">অধ্যায়-২: সেট ও ফাংশন</option>
	<option value="অধ্যায়-৩: বীজগাণিতিক রাশি">অধ্যায়-৩: বীজগাণিতিক রাশি</option>
	<option value="অধ্যায়-৪: সূচক ও লগারিদম">অধ্যায়-৪: সূচক ও লগারিদম</option>
	<option value="অধ্যায়-৫: এক চলকবিশিষ্ট সমীকরণ">অধ্যায়-৫: এক চলকবিশিষ্ট সমীকরণ</option>
	<option value="অধ্যায়-৬: রেখা, কোণ ও ত্রিভুজ">অধ্যায়-৬: রেখা, কোণ ও ত্রিভুজ</option>
	<option value="অধ্যায়-৭: ব্যবহারিক জ্যামিতি">অধ্যায়-৭: ব্যবহারিক জ্যামিতি</option>
	<option value="অধ্যায়-৮: বৃত্ত">অধ্যায়-৮: বৃত্ত</option>
	<option value="অধ্যায়-৯: ত্রিকোণমিতিক অনুপাত">অধ্যায়-৯: ত্রিকোণমিতিক অনুপাত</option>
	<option value="অধ্যায়-১০: দূরত্ব ও উচ্চতা">অধ্যায়-১০: দূরত্ব ও উচ্চতা</option>
	<option value="অধ্যায়-১১: বিজগনিতীয় অনুপাত ও সমানুপাত">অধ্যায়-১১: বিজগনিতীয় অনুপাত ও সমানুপাত</option>
	<option value="অধ্যায়-১২: দুই চলকবিশিষ্ট সরল সহসমীকরণ">অধ্যায়-১২: দুই চলকবিশিষ্ট সরল সহসমীকরণ</option>
	<option value="অধ্যায়-১৩: সসীম ধারা">অধ্যায়-১৩: সসীম ধারা</option>
	<option value="অধ্যায়-১৪: অনুপাত, সদৃশতা ও প্রতিসমতা">অধ্যায়-১৪: অনুপাত, সদৃশতা ও প্রতিসমতা</option>
	<option value="অধ্যায়-১৫: ক্ষেত্রফল সম্পর্কিত উপপাদ্য ও সম্পাদ্য">অধ্যায়-১৫: ক্ষেত্রফল সম্পর্কিত উপপাদ্য ও সম্পাদ্য</option>
	<option value="অধ্যায়-১৬: পরিমিতি">অধ্যায়-১৬: পরিমিতি</option>
	<option value="অধ্যায়-১৭: পরিসংখ্যান">অধ্যায়-১৭: পরিসংখ্যান</option>


	<?php
	}
	if($subject=='উচ্চতর গনিত'){
		?>
	<option value="অধ্যায়-১: সেট ও ফাংশন">অধ্যায়-১: সেট ও ফাংশন</option>
	<option value="অধ্যায়-২: বীজগাণিতিক রাশি">অধ্যায়-২: বীজগাণিতিক রাশি</option>
	<option value="অধ্যায়-৩: জ্যামিতি">অধ্যায়-৩: জ্যামিতি</option>
	<option value="অধ্যায়-৪: জ্যামিতিক অঙ্কন">অধ্যায়-৪: জ্যামিতিক অঙ্কন</option>
	<option value="অধ্যায়-৫: সমীকরণ">অধ্যায়-৫: সমীকরণ</option>
	<option value="অধ্যায়-৬: অসমতা">অধ্যায়-৬: অসমতা</option>
	<option value="অধ্যায়-৭: অসীম ধারা">অধ্যায়-৭: অসীম ধারা</option>
	<option value="অধ্যায়-৮: ত্রিকোণমিতি">অধ্যায়-৮: ত্রিকোণমিতি</option>
	<option value="অধ্যায়-৯: সূচকীয় ও লগারিদমীয় ফাংশন">অধ্যায়-৯: সূচকীয় ও লগারিদমীয় ফাংশন</option>
	<option value="অধ্যায়-১০: দ্বিপদী বিস্তৃতি">অধ্যায়-১০: দ্বিপদী বিস্তৃতি</option>
	<option value="অধ্যায়-১১: স্থানাঙ্ক জ্যামিতি">অধ্যায়-১১: স্থানাঙ্ক জ্যামিতি</option>
	<option value="অধ্যায়-১২: সমতলীয় ভেক্টর">অধ্যায়-১২: সমতলীয় ভেক্টর</option>
	<option value="অধ্যায়-১৩: ঘন জ্যামিতি">অধ্যায়-১৩: ঘন জ্যামিতি</option>
	<option value="অধ্যায়-১৪: সম্ভাবনা">অধ্যায়-১৪: সম্ভাবনা</option>

	<?php
	}

	if($subject=='জীববিজ্ঞান'){
		?>

	<option value="অধ্যায়-১: জীবন পাঠ">অধ্যায়-১: জীবন পাঠ</option>
	<option value="অধ্যায়-২: জীবকোষ ও টিস্যু">অধ্যায়-২: জীবকোষ ও টিস্যু</option>
	<option value="অধ্যায়-৩: কোষ বিভাজন">অধ্যায়-৩: কোষ বিভাজন</option>
	<option value="অধ্যায়-৪: জীবনীশক্তি">অধ্যায়-৪: জীবনীশক্তি</option>
	<option value="অধ্যায়-৫: খাদ্য, পুষ্টি এবং পরিপাক">অধ্যায়-৫: খাদ্য, পুষ্টি এবং পরিপাক</option>
	<option value="অধ্যায়-৬: জীবে পরিবহন">অধ্যায়-৬: জীবে পরিবহন</option>
	<option value="অধ্যায়-৭: গ্যাসীয় বিনিময়">অধ্যায়-৭: গ্যাসীয় বিনিময়</option>
	<option value="অধ্যায়-৮: রেচন প্রক্রিয়া">অধ্যায়-৮: রেচন প্রক্রিয়া</option>
	<option value="অধ্যায়-৯: দৃঢ়তা প্রদান ও চলন">অধ্যায়-৯: দৃঢ়তা প্রদান ও চলন</option>
	<option value="অধ্যায়-১০: সমন্বয়">অধ্যায়-১০: সমন্বয়</option>
	<option value="অধ্যায়-১১: জীবের প্রজনন">অধ্যায়-১১: জীবের প্রজনন</option>
	<option value="অধ্যায়-১২: জীবের বংশগতি ও বিবর্তন">অধ্যায়-১২: জীবের বংশগতি ও বিবর্তন</option>
	<option value="অধ্যায়-১৩: জীবের পরিবেশ">অধ্যায়-১৩: জীবের পরিবেশ</option>
	<option value="অধ্যায়-১৪: জীবপ্রযুক্তি">অধ্যায়-১৪: জীবপ্রযুক্তি</option>

	<?php
	}
	if($subject=='রসায়ন'){
		?>

	<option value="অধ্যায়-১: রসায়নের ধারণা">অধ্যায়-১: রসায়নের ধারণা</option>
	<option value="অধ্যায়-২: পদার্থের অবস্থা">অধ্যায়-২: পদার্থের অবস্থা</option>
	<option value="অধ্যায়-৩: পদার্থের গঠন">অধ্যায়-৩: পদার্থের গঠন</option>
	<option value="অধ্যায়-৪: পর্যায় সারণি">অধ্যায়-৪: পর্যায় সারণি</option>
	<option value="অধ্যায়-৫: রাসায়নিক বন্ধন">অধ্যায়-৫: রাসায়নিক বন্ধন</option>
	<option value="অধ্যায়-৬: মোলের ধারণা ও রাসায়নিক গণনা">অধ্যায়-৬: মোলের ধারণা ও রাসায়নিক গণনা</option>
	<option value="অধ্যায়-৭: রাসায়নিক বিক্রিয়া">অধ্যায়-৭: রাসায়নিক বিক্রিয়া</option>
	<option value="অধ্যায়-৮: রসায়ন ও শক্তি">অধ্যায়-৮: রসায়ন ও শক্তি</option>
	<option value="অধ্যায়-৯: এসিড-ক্ষারক সমতা">অধ্যায়-৯: এসিড-ক্ষারক সমতা</option>
	<option value="অধ্যায়-১০: খনিজ সম্পদ: ধাতু-অধাতু">অধ্যায়-১০: খনিজ সম্পদ: ধাতু-অধাতু</option>
	<option value="অধ্যায়-১১: খনিজ সম্পদ জিবাশ্ন">অধ্যায়-১১: খনিজ সম্পদ জিবাশ্ন</option>
	<option value="অধ্যায়-১২: আমাদের জীবনে রসায়ন">অধ্যায়-১২: আমাদের জীবনে রসায়ন</option>

	<?php
	}

if($subject=='পদার্থ বিজ্ঞান'){
		?>

	<option value="অধ্যায়-১: ভৌত রাশি ও পরিমাপ">অধ্যায়-১: ভৌত রাশি ও পরিমাপ</option>
	<option value="অধ্যায়-২: গতি">অধ্যায়-২: গতি</option>
	<option value="অধ্যায়-৩: বল">অধ্যায়-৩: বল</option>
	<option value="অধ্যায়-৪: কাজ, ক্ষমতা ও শক্তি">অধ্যায়-৪: কাজ, ক্ষমতা ও শক্তি</option>
	<option value="অধ্যায়-৫: পদার্থের অবস্থা ও চাপ">অধ্যায়-৫: পদার্থের অবস্থা ও চাপ</option>
	<option value="অধ্যায়-৬: বস্তুর উপর তাপের প্রভাব">অধ্যায়-৬: বস্তুর উপর তাপের প্রভাব</option>
	<option value="অধ্যায়-৭: তরঙ্গ ও শব্দ">অধ্যায়-৭: তরঙ্গ ও শব্দ</option>
	<option value="অধ্যায়-৮: আলোর প্রতিফলন">অধ্যায়-৮: আলোর প্রতিফলন</option>
	<option value="অধ্যায়-৯: আলোর প্রতিসরণ">অধ্যায়-৯: আলোর প্রতিসরণ</option>
	<option value="অধ্যায়-১০: স্থির বিদ্যুৎ">অধ্যায়-১০: স্থির বিদ্যুৎ</option>
	<option value="অধ্যায়-১১: চল বিদ্যুৎ">অধ্যায়-১১: চল বিদ্যুৎ</option>
	<option value="অধ্যায়-১২: বিদ্যুতের চৌম্বক ক্রিয়া">অধ্যায়-১২: বিদ্যুতের চৌম্বক ক্রিয়া</option>
	<option value="অধ্যায়-১৩: আধুনিক পদার্থবিজ্ঞান ও ইলেকট্রনিক্স">অধ্যায়-১৩: আধুনিক পদার্থবিজ্ঞান ও ইলেকট্রনিক্স</option>
	<option value="অধ্যায়-১৪: জীবন বাঁচাতে পদার্থবিজ্ঞান">অধ্যায়-১৪: জীবন বাঁচাতে পদার্থবিজ্ঞান</option>

	<?php
	}

if($subject=='বাংলাদেশের ইতিহাস ও বিশ্বসভ্যতা'){
		?>

	<option value="অধ্যায়-১: ইতিহাস পরিচিতি">অধ্যায়-১: ইতিহাস পরিচিতি</option>
	<option value="অধ্যায়-২: বিশ্বসভ্যতা(মিশর, সিন্ধু, গ্রিক ও রোম) ">অধ্যায়-২: বিশ্বসভ্যতা(মিশর, সিন্ধু, গ্রিক ও রোম) </option>
	<option value="অধ্যায়-৩: প্রাচীন বাংলার জনপদ">অধ্যায়-৩: প্রাচীন বাংলার জনপদ</option>
	<option value="অধ্যায়-৪: প্রাচীন বাংলার রাজনৈতিক ইতিহাস(খ্রিষ্টপূর্বাব্দ ৩২৬-১২০৪ খ্রিষ্টাব্দ)">অধ্যায়-৪: প্রাচীন বাংলার রাজনৈতিক ইতিহাস(খ্রিষ্টপূর্বাব্দ ৩২৬-১২০৪ খ্রিষ্টাব্দ)</option>
	<option value="অধ্যায়-৫: প্রাচীন বাংলার সামাজিক, অর্থনৈতিক ও সাংস্কৃতিক ইতিহাস">অধ্যায়-৫: প্রাচীন বাংলার সামাজিক, অর্থনৈতিক ও সাংস্কৃতিক ইতিহাস</option>
	<option value="অধ্যায়-৬: মধ্যযুগের বাংলার রাজনৈতিক ইতিহাস (১২০৪-১৭৫৭ খ্রিষ্টাব্দ)">অধ্যায়-৬: মধ্যযুগের বাংলার রাজনৈতিক ইতিহাস (১২০৪-১৭৫৭ খ্রিষ্টাব্দ)</option>
	<option value="অধ্যায়-৭: মধ্যযুগের বাংলার সামাজিক, অর্থনৈতিক ও সাংস্কৃতিক ইতিহাস">অধ্যায়-৭: মধ্যযুগের বাংলার সামাজিক, অর্থনৈতিক ও সাংস্কৃতিক ইতিহাস</option>
	<option value="অধ্যায়-৮: বাংলায় ইংরেজ শাসনের সূচনাপর্ব">অধ্যায়-৮: বাংলায় ইংরেজ শাসনের সূচনাপর্ব</option>
	<option value="অধ্যায়-৯: ইংরেজ শাসন আমলে বাংলায় প্রতিরোধ, নবজাগরণ ও সংস্কার আন্দোলন">অধ্যায়-৯: ইংরেজ শাসন আমলে বাংলায় প্রতিরোধ, নবজাগরণ ও সংস্কার আন্দোলন</option>
	<option value="অধ্যায়-১০: ইংরেজ শাসন আমলে বাংলার স্বাধিকার আন্দোলন">অধ্যায়-১০: ইংরেজ শাসন আমলে বাংলার স্বাধিকার আন্দোলন</option>
	<option value="অধ্যায়-১১: ভাষা আন্দোলন ও পরবর্তী রাজনৈতিক ঘটনাপ্রবাহ">অধ্যায়-১১: ভাষা আন্দোলন ও পরবর্তী রাজনৈতিক ঘটনাপ্রবাহ</option>
	<option value="অধ্যায়-১২: সামরিক শাসন ও স্বধিকার আন্দোলন (১৯৫৮-১৯৬৯)">অধ্যায়-১২: সামরিক শাসন ও স্বধিকার আন্দোলন (১৯৫৮-১৯৬৯)</option>
	<option value="অধ্যায়-১৩: সত্তরের নির্বাচন এবং মুক্তিযুদ্ধ">অধ্যায়-১৩: সত্তরের নির্বাচন এবং মুক্তিযুদ্ধ</option>
	<option value="অধ্যায়-১৪: বঙ্গবন্ধু শেখ মুজিবুর রহমানের শাসনকাল (১৯৭২-১৯৭৫)">অধ্যায়-১৪: বঙ্গবন্ধু শেখ মুজিবুর রহমানের শাসনকাল (১৯৭২-১৯৭৫)</option>
	<option value="অধ্যায়-১৫: সামরিক শাসন ও পরবর্তী ঘটনাপ্রবাহ (১৯৭৫-১৯৯০)">অধ্যায়-১৫: সামরিক শাসন ও পরবর্তী ঘটনাপ্রবাহ (১৯৭৫-১৯৯০)</option>

	<?php
	}

if($subject=='সাধারণ বিজ্ঞান'){
		?>

	<option value="অধ্যায়-১: উন্নততর জীবনধারা">অধ্যায়-১: উন্নততর জীবনধারা</option>
	<option value="অধ্যায়-২: জীবনের জন্য পানি">অধ্যায়-২: জীবনের জন্য পানি</option>
	<option value="অধ্যায়-৩: হৃদযন্ত্রের যত কথা">অধ্যায়-৩: হৃদযন্ত্রের যত কথা</option>
	<option value="অধ্যায়-৪: নবজীবনের সূচনা">অধ্যায়-৪: নবজীবনের সূচনা</option>
	<option value="অধ্যায়-৫: দেখতে হলে আলো চাই">অধ্যায়-৫: দেখতে হলে আলো চাই</option>
	<option value="অধ্যায়-৬: পলিমার">অধ্যায়-৬: পলিমার</option>
	<option value="অধ্যায়-৭: অম্ল, ক্ষারক ও লবণের ব্যবহার">অধ্যায়-৭: অম্ল, ক্ষারক ও লবণের ব্যবহার</option>
	<option value="অধ্যায়-৮: আমাদের সম্পদ">অধ্যায়-৮: আমাদের সম্পদ</option>
	<option value="অধ্যায়-৯: দুর্যোগের সাথে বসবাস">অধ্যায়-৯: দুর্যোগের সাথে বসবাস</option>
	<option value="অধ্যায়-১০: এসো বলকে জানি">অধ্যায়-১০: এসো বলকে জানি</option>
	<option value="অধ্যায়-১১: জীবপ্রযুক্তি">অধ্যায়-১১: জীবপ্রযুক্তি</option>
	<option value="অধ্যায়-১২: প্রাত্যহিক জীবনে তড়িৎ">অধ্যায়-১২: প্রাত্যহিক জীবনে তড়িৎ</option>
	<option value="অধ্যায়-১৩: সবাই কাছাকাছি">অধ্যায়-১৩: সবাই কাছাকাছি</option>
	<option value="অধ্যায়-১৪: জীবন বাঁচাতে বিজ্ঞান">অধ্যায়-১৪: জীবন বাঁচাতে বিজ্ঞান</option>

	<?php
	}

if($subject=='ভূগোল ও পরিবেশ'){
		?>

	<option value="অধ্যায়-১: ভূগোল ও পরিবেশ">অধ্যায়-১: ভূগোল ও পরিবেশ</option>
	<option value="অধ্যায়-২: মহাবিশ্ব ও আমাদের পৃথিবী">অধ্যায়-২: মহাবিশ্ব ও আমাদের পৃথিবী</option>
	<option value="অধ্যায়-৩: মানচিত্র গঠন ও ব্যবহার">অধ্যায়-৩: মানচিত্র গঠন ও ব্যবহার</option>
	<option value="অধ্যায়-৪: পৃথিবীর অভ্যন্তরীণ ও বাহ্যিক গঠন">অধ্যায়-৪: পৃথিবীর অভ্যন্তরীণ ও বাহ্যিক গঠন</option>
	<option value="অধ্যায়-৫: বায়ুমণ্ডল">অধ্যায়-৫: বায়ুমণ্ডল</option>
	<option value="অধ্যায়-৬: বারিমন্ডল">অধ্যায়-৬: বারিমন্ডল</option>
	<option value="অধ্যায়-৭: জনসংখ্যা">অধ্যায়-৭: জনসংখ্যা</option>
	<option value="অধ্যায়-৮: মানব বসতি">অধ্যায়-৮: মানব বসতি</option>
	<option value="অধ্যায়-৯: সম্পদ ও অর্থনৈতিক কার্যাবলী">অধ্যায়-৯: সম্পদ ও অর্থনৈতিক কার্যাবলী</option>
	<option value="অধ্যায়-১০: বাংলাদেশের ভৌগোলিক বিবরণ ">অধ্যায়-১০: বাংলাদেশের ভৌগোলিক বিবরণ </option>
	<option value="অধ্যায়-১১: বাংলাদেশের সম্পদ ও শিল্প">অধ্যায়-১১: বাংলাদেশের সম্পদ ও শিল্প</option>
	<option value="অধ্যায়-১২: বাংলাদেশের যোগাযোগ ব্যবস্থা ও বাণিজ্য">অধ্যায়-১২: বাংলাদেশের যোগাযোগ ব্যবস্থা ও বাণিজ্য</option>
	<option value="অধ্যায়-১৩: বাংলাদেশের উন্নয়ন কর্মকাণ্ড ও পরিবেশের ভারসাম্য">অধ্যায়-১৩: বাংলাদেশের উন্নয়ন কর্মকাণ্ড ও পরিবেশের ভারসাম্য</option>
	<option value="অধ্যায়-১৪: বাংলাদেশের প্রাকৃতিক দুর্যোগ">অধ্যায়-১৪: বাংলাদেশের প্রাকৃতিক দুর্যোগ</option>
	<option value="অধ্যায়-১৫: টেকসই উন্নয়ন অভীষ্ট (এসডিজি)">অধ্যায়-১৫: টেকসই উন্নয়ন অভীষ্ট (এসডিজি)</option>

	<?php
	}
if($subject=='অর্থনীতি'){
		?>

	<option value="অধ্যায়-১: অর্থনীতির পরিচয়">অধ্যায়-১: অর্থনীতির পরিচয়</option>
	<option value="অধ্যায়-২: অর্থনীতির গুরুত্বপূর্ণ ধারণাসমূহ">অধ্যায়-২: অর্থনীতির গুরুত্বপূর্ণ ধারণাসমূহ</option>
	<option value="অধ্যায়-৩: উপযোগ, চাহিদা, যোগান ও ভারসাম্য">অধ্যায়-৩: উপযোগ, চাহিদা, যোগান ও ভারসাম্য</option>
	<option value="অধ্যায়-৪: উৎপাদন ও সংগঠন">অধ্যায়-৪: উৎপাদন ও সংগঠন</option>
	<option value="অধ্যায়-৫: বাজার">অধ্যায়-৫: বাজার</option>
	<option value="অধ্যায়-৬: জাতীয় আয় ও এর পরিমাপ">অধ্যায়-৬: জাতীয় আয় ও এর পরিমাপ</option>
	<option value="অধ্যায়-৭: অর্থ ও ব্যাংক ব্যবস্থা">অধ্যায়-৭: অর্থ ও ব্যাংক ব্যবস্থা</option>
	<option value="অধ্যায়-৮: বাংলাদেশের অর্থনীতি">অধ্যায়-৮: বাংলাদেশের অর্থনীতি</option>
	<option value="অধ্যায়-৯: বাংলাদেশের গুরুত্বপূর্ণ অর্থনৈতিক প্রসঙ্গ">অধ্যায়-৯: বাংলাদেশের গুরুত্বপূর্ণ অর্থনৈতিক প্রসঙ্গ</option>
	<option value="অধ্যায়-১০: বাংলাদেশ সরকারের অর্থ ব্যবস্থা">অধ্যায়-১০: বাংলাদেশ সরকারের অর্থ ব্যবস্থা</option>

	<?php
	}

if($subject=='পৌরনীতি ও নাগরিকতা'){
		?>

<!-- 	<option value="অধ্যায়-১: ">অধ্যায়-১: </option>
	<option value="অধ্যায়-২: ">অধ্যায়-২: </option>
	<option value="অধ্যায়-৩: ">অধ্যায়-৩: </option>
	<option value="অধ্যায়-৪: ">অধ্যায়-৪: </option>
	<option value="অধ্যায়-৫: ">অধ্যায়-৫: </option>
	<option value="অধ্যায়-৬: ">অধ্যায়-৬: </option>
	<option value="অধ্যায়-৭: ">অধ্যায়-৭: </option>
	<option value="অধ্যায়-৮: ">অধ্যায়-৮: </option>
	<option value="অধ্যায়-৯: ">অধ্যায়-৯: </option>
	<option value="অধ্যায়-১০: ">অধ্যায়-১০: </option>
	<option value="অধ্যায়-১১: ">অধ্যায়-১১: </option>
	<option value="অধ্যায়-১২: ">অধ্যায়-১২: </option>
	<option value="অধ্যায়-১৩: ">অধ্যায়-১৩: </option>
	<option value="অধ্যায়-১৪: ">অধ্যায়-১৪: </option>
	<option value="অধ্যায়-১৫: ">অধ্যায়-১৫: </option>
	<option value="অধ্যায়-১৬: ">অধ্যায়-১৬: </option>
	<option value="অধ্যায়-১৭: ">অধ্যায়-১৭: </option> -->
	<option value="অধ্যায়-১: পৌরনীতি ও নাগরিকতা">অধ্যায়-১: পৌরনীতি ও নাগরিকতা</option>
	<option value="অধ্যায়-২: নাগরিক ও নাগরিকতা">অধ্যায়-২: নাগরিক ও নাগরিকতা</option>
	<option value="অধ্যায়-৩: আইন, স্বাধীনতা ও সাম্য">অধ্যায়-৩: আইন, স্বাধীনতা ও সাম্য</option>
	<option value="অধ্যায়-৪: রাষ্ট্র ও সরকার ব্যবস্থা">অধ্যায়-৪: রাষ্ট্র ও সরকার ব্যবস্থা</option>
	<option value="অধ্যায়-৫: সংবিধান">অধ্যায়-৫: সংবিধান</option>
	<option value="অধ্যায়-৬: বাংলাদেশের সরকার ব্যবস্থা">অধ্যায়-৬: বাংলাদেশের সরকার ব্যবস্থা</option>
	<option value="অধ্যায়-৭: গণতন্ত্রে রাজনৈতিক দল ও নির্বাচন">অধ্যায়-৭: গণতন্ত্রে রাজনৈতিক দল ও নির্বাচন</option>
	<option value="অধ্যায়-৮: বাংলাদেশের স্থানীয় সরকার ব্যবস্থা">অধ্যায়-৮: বাংলাদেশের স্থানীয় সরকার ব্যবস্থা</option>
	<option value="অধ্যায়-৯: নাগরিক সমস্যা ও আমাদের করণীয়">অধ্যায়-৯: নাগরিক সমস্যা ও আমাদের করণীয়</option>
	<option value="অধ্যায়-১০: স্বাধীন বাংলাদেশের অভ্যুদয়ে নাগরিক চেতনা">অধ্যায়-১০: স্বাধীন বাংলাদেশের অভ্যুদয়ে নাগরিক চেতনা</option>
	<option value="অধ্যায়-১১: বাংলাদেশ ও আন্তর্জাতিক সংগঠন">অধ্যায়-১১: বাংলাদেশ ও আন্তর্জাতিক সংগঠন</option>
	
	<?php
	}

if($subject=='কৃষিশিক্ষা'){
		?>

    <option value="অধ্যায়-১: কৃষি প্রযুক্তি">অধ্যায়-১: কৃষি প্রযুক্তি</option>
	<option value="অধ্যায়-২: কৃষি উপকরণ">অধ্যায়-২: কৃষি উপকরণ</option>
	<option value="অধ্যায়-৩: কৃষি ও জলবায়ু">অধ্যায়-৩: কৃষি ও জলবায়ু</option>
	<option value="অধ্যায়-৪: কৃষিজ উৎপাদন">অধ্যায়-৪: কৃষিজ উৎপাদন</option>
	<option value="অধ্যায়-৫: বনায়ন">অধ্যায়-৫: বনায়ন</option>
	<option value="অধ্যায়-৬: কৃষি সমবায়">অধ্যায়-৬: কৃষি সমবায়</option>
	<option value="অধ্যায়-৭: পারিবারিক খামার">অধ্যায়-৭: পারিবারিক খামার</option>

	<?php
	}

	if($subject=='হিসাববিজ্ঞান'){
		?>

    <option value="অধ্যায়-১: হিসাববিজ্ঞান পরিচিতি">অধ্যায়-১: হিসাববিজ্ঞান পরিচিতি</option>
	<option value="অধ্যায়-২: লেনদেন">অধ্যায়-২: লেনদেন</option>
	<option value="অধ্যায়-৩: দুতরফা দাখিলা পদ্ধতি">অধ্যায়-৩: দুতরফা দাখিলা পদ্ধতি</option>
	<option value="অধ্যায়-৪: মূলধন ও মুনাফা জাতীয় লেনদেন">অধ্যায়-৪: মূলধন ও মুনাফা জাতীয় লেনদেন</option>
	<option value="অধ্যায়-৫: হিসাব">অধ্যায়-৫: হিসাব</option>
	<option value="অধ্যায়-৬: জাবেদা">অধ্যায়-৬: জাবেদা</option>
	<option value="অধ্যায়-৭: খতিয়ান">অধ্যায়-৭: খতিয়ান</option>
	<option value="অধ্যায়-৮: নগদান বই">অধ্যায়-৮: নগদান বই</option>
	<option value="অধ্যায়-৯: রেউয়ামিল">অধ্যায়-৯: রেউয়ামিল</option>
	<option value="অধ্যায়-১০: আর্থিক বিবরণী">অধ্যায়-১০: আর্থিক বিবরণী</option>
	<option value="অধ্যায়-১১: পণ্যের ক্রয়মূল্য, উৎপাদন ব্যয় ও বিক্রয়মূল্য">অধ্যায়-১১: পণ্যের ক্রয়মূল্য, উৎপাদন ব্যয় ও বিক্রয়মূল্য</option>
	<option value="অধ্যায়-১২: পারিবারিক ও আত্মকর্মসংস্থানমূলক উদ্যোগের হিসাব">অধ্যায়-১২: পারিবারিক ও আত্মকর্মসংস্থানমূলক উদ্যোগের হিসাব</option>

	<?php
	}

}
// Class Ten kintu acei.

if ($class==11 || $class==12) {
	if ($subject=='উচ্চতর গনিত প্রথম পত্র') {
		?>
	<option value="অধ্যায়-১: ম্যাট্রিক্স ও নির্ণায়ক">অধ্যায়-১: ম্যাট্রিক্স ও নির্ণায়ক</option>
	<option value="অধ্যায়-২: ভেক্টর">অধ্যায়-২: ভেক্টর</option>
	<option value="অধ্যায়-৩: সরলরেখা">অধ্যায়-৩: সরলরেখা</option>
	<option value="অধ্যায়-৪: বৃত্ত">অধ্যায়-৪: বৃত্ত</option>
	<option value="অধ্যায়-৫: বিন্যাস  ও সমাবেশ">অধ্যায়-৫: বিন্যাস  ও সমাবেশ</option>
	<option value="অধ্যায়-৬: ত্রিকোণমিতিক  অনুপাত">অধ্যায়-৬: ত্রিকোণমিতিক  অনুপাত</option>
	<option value="অধ্যায়-৭: সংযুক্ত কোণের ত্রিকোণমিতিক অনুপাত">অধ্যায়-৭: সংযুক্ত কোণের ত্রিকোণমিতিক অনুপাত</option>
	<option value="অধ্যায়-৮: ফাংশন ও ফাংশনের লেখচিত্র">অধ্যায়-৮: ফাংশন ও ফাংশনের লেখচিত্র</option>
	<option value="অধ্যায়-৯: অন্তরীকরণ">অধ্যায়-৯: অন্তরীকরণ</option>
	<option value="অধ্যায়-১০: যোগজীকরণ">অধ্যায়-১০: যোগজীকরণ</option>
		<?php
	}
}
?>