<?php 
$class = $_GET['class'];
if (isset($_GET['select'])) {
function match($a,$b)
{
	echo "selected";
}
}
?>
<?php 
if ($class=='') {
	?>
<option value="">-- SELECT --</option>

	<?php
}
if ($class=='6' || $class=='7') {
?>
<option value="">-- SELECT --</option>
<option value="বাংলা প্রথম পত্র">বাংলা প্রথম পত্র</option>
<option value="বাংলা দ্বিতীয় পত্র">বাংলা দ্বিতীয় পত্র</option>
<option value="ইংরেজি প্রথম পত্র">ইংরেজি প্রথম পত্র</option>
<option value="ইংরেজি দ্বিতীয় পত্র">ইংরেজি দ্বিতীয় পত্র</option>
<option value="গনিত">গনিত</option>
<option value="সাধারণ বিজ্ঞান">বিজ্ঞান</option>
<option value="কৃষিশিক্ষা">কৃষিশিক্ষা</option>
<option value="বাংলাদেশ ও বিশ্ব পরিচয়">বাংলাদেশ ও বিশ্ব পরিচয়</option>
<option value="তথ্য ও যোগাযোগ প্রযুক্তি">তথ্য ও যোগাযোগ প্রযুক্তি</option>
<option value="ইসলাম ও নৈতিক শিক্ষা">ইসলাম ও নৈতিক শিক্ষা</option>
<option value="হিন্দু ধর্ম ও নৈতিক শিক্ষা">হিন্দু ধর্ম ও নৈতিক শিক্ষা</option>
<option value="খ্রিস্টান ধর্ম ও নৈতিক শিক্ষা">খ্রিস্টান ধর্ম ও নৈতিক শিক্ষা</option>
<option value="বৌদ্ধ ধর্ম ও নৈতিক শিক্ষা">বৌদ্ধ ধর্ম ও নৈতিক শিক্ষা</option>
<option value="চারু ও কারু কলা">চারু ও কারু কলা</option>
<option value="কর্ম ও জীবনমুখী শিক্ষা">কর্ম ও জীবনমুখী শিক্ষা</option>
<option value="শারীরিক শিক্ষা ও স্বাস্থ্য">শারীরিক শিক্ষা ও স্বাস্থ্য</option>
<option value="ক্ষুদ্র ও নৃগােষ্ঠীর ভাষা ও সংস্কৃতি">ক্ষুদ্র ও নৃগােষ্ঠীর ভাষা ও সংস্কৃতি</option>
<option value="গার্হস্থ্য বিজ্ঞান">গার্হস্থ্য বিজ্ঞান</option>
<?php
}
?>
<?php 
if ($class=='8') {
?>
<option value="">-- SELECT --</option>
<option value="বাংলা প্রথম পত্র">বাংলা প্রথম পত্র</option>
<option value="বাংলা দ্বিতীয় পত্র">বাংলা দ্বিতীয় পত্র</option>
<option value="ইংরেজি প্রথম পত্র">ইংরেজি প্রথম পত্র</option>
<option value="ইংরেজি দ্বিতীয় পত্র">ইংরেজি দ্বিতীয় পত্র</option>
<option value="গনিত">গনিত</option>
<option value="সাধারণ বিজ্ঞান">বিজ্ঞান</option>
<option value="কৃষিশিক্ষা">কৃষিশিক্ষা</option>
<option value="বাংলাদেশ ও বিশ্ব পরিচয়">বাংলাদেশ ও বিশ্ব পরিচয়</option>
<option value="তথ্য ও যোগাযোগ প্রযুক্তি">তথ্য ও যোগাযোগ প্রযুক্তি</option>
<option value="ইসলাম ও নৈতিক শিক্ষা">ইসলাম ও নৈতিক শিক্ষা</option>
<option value="হিন্দু ধর্ম ও নৈতিক শিক্ষা">হিন্দু ধর্ম ও নৈতিক শিক্ষা</option>
<option value="খ্রিস্টান ধর্ম ও নৈতিক শিক্ষা">খ্রিস্টান ধর্ম ও নৈতিক শিক্ষা</option>
<option value="বৌদ্ধ ধর্ম ও নৈতিক শিক্ষা">বৌদ্ধ ধর্ম ও নৈতিক শিক্ষা</option>
<option value="চারু ও কারু কলা">চারু ও কারু কলা</option>
<option value="কর্ম ও জীবনমুখী শিক্ষা">কর্ম ও জীবনমুখী শিক্ষা</option>
<option value="শারীরিক শিক্ষা ও স্বাস্থ্য">শারীরিক শিক্ষা ও স্বাস্থ্য</option>
<option value="গার্হস্থ্য বিজ্ঞান">গার্হস্থ্য বিজ্ঞান</option>
<?php
}
?>

<?php 
if ($class=='9' || $class=='10') {
?>

<option value="">-- SELECT --</option>
<option value="বাংলা প্রথম পত্র">বাংলা প্রথম পত্র</option>
<option value="বাংলা দ্বিতীয় পত্র">বাংলা দ্বিতীয় পত্র</option>
<option value="ইংরেজি প্রথম পত্র">ইংরেজি প্রথম পত্র</option>
<option value="ইংরেজি দ্বিতীয় পত্র">ইংরেজি দ্বিতীয় পত্র</option>
<option value="গনিত">গনিত</option>


<option value="উচ্চতর গনিত">উচ্চতর গনিত</option>
<option value="জীববিজ্ঞান">জীববিজ্ঞান</option>
<option value="রসায়ন">রসায়ন</option>
<option value="পদার্থ বিজ্ঞান">পদার্থ বিজ্ঞান</option>



<option value="বাংলাদেশের ইতিহাস ও বিশ্বসভ্যতা ">বাংলাদেশের ইতিহাস ও বিশ্বসভ্যতা </option>
<option value="সাধারণ বিজ্ঞান">সাধারণ বিজ্ঞান</option>
<option value="ভূগোল ও পরিবেশ">ভূগোল ও পরিবেশ</option>
<option value="অর্থনীতি">অর্থনীতি</option>
<option value="পৌরনীতি ও নাগরিকতা">পৌরনীতি ও নাগরিকতা</option>
<option value="কৃষিশিক্ষা">কৃষিশিক্ষা</option>



<option value="হিসাববিজ্ঞান">হিসাববিজ্ঞান</option>
<option value="ফিন্যান্স ও ব্যাংকিং">ফিন্যান্স ও ব্যাংকিং</option>
<option value="ব্যবসায় উদ্যোগ">ব্যবসায় উদ্যোগ</option>



<option value="বাংলাদেশ ও বিশ্ব পরিচয়">বাংলাদেশ ও বিশ্ব পরিচয়</option>
<option value="তথ্য ও যোগাযোগ প্রযুক্তি">তথ্য ও যোগাযোগ প্রযুক্তি</option>
<option value="ইসলাম ও নৈতিক শিক্ষা">ইসলাম ও নৈতিক শিক্ষা</option>
<option value="হিন্দু ধর্ম ও নৈতিক শিক্ষা">হিন্দু ধর্ম ও নৈতিক শিক্ষা</option>
<option value="খ্রিস্টান ধর্ম ও নৈতিক শিক্ষা">খ্রিস্টান ধর্ম ও নৈতিক শিক্ষা</option>
<option value="বৌদ্ধ ধর্ম ও নৈতিক শিক্ষা">বৌদ্ধ ধর্ম ও নৈতিক শিক্ষা</option>
<option value="চারু ও কারু কলা">চারু ও কারু কলা</option>
<option value="কর্ম ও জীবনমুখী শিক্ষা">কর্ম ও জীবনমুখী শিক্ষা</option>
<option value="শারীরিক শিক্ষা">শারীরিক শিক্ষা</option>
<?php
}
?>
<?php 
if ($class=='11' || $class=='12') {
?>
<option value="">-- SELECT --</option>
<option value="বাংলা প্রথম পত্র">বাংলা প্রথম পত্র</option>
<option value="বাংলা দ্বিতীয় পত্র">বাংলা দ্বিতীয় পত্র</option>
<option value="ইংরেজি প্রথম পত্র">ইংরেজি প্রথম পত্র</option>
<option value="ইংরেজি দ্বিতীয় পত্র">ইংরেজি দ্বিতীয় পত্র</option>
<option value="তথ্য ও যোগাযোগ প্রযুক্তি">তথ্য ও যোগাযোগ প্রযুক্তি</option>


<option value="পদার্থ বিজ্ঞান প্রথম পত্র">পদার্থ বিজ্ঞান প্রথম পত্র</option>
<option value="পদার্থ বিজ্ঞান দ্বিতীয় পত্র">পদার্থ বিজ্ঞান দ্বিতীয় পত্র</option>
<option value="রসায়ন প্রথম পত্র">রসায়ন প্রথম পত্র</option>
<option value="রসায়ন দ্বিতীয় পত্র">রসায়ন দ্বিতীয় পত্র</option>
<option value="জীববিজ্ঞান প্রথম পত্র">জীববিজ্ঞান প্রথম পত্র</option>
<option value="জীববিজ্ঞান দ্বিতীয় পত্র">জীববিজ্ঞান দ্বিতীয় পত্র</option>
<option value="উচ্চতর গনিত প্রথম পত্র">উচ্চতর গনিত প্রথম পত্র</option>
<option value="উচ্চতর গনিত দ্বিতীয় পত্র">উচ্চতর গনিত দ্বিতীয় পত্র</option>
<option value="মনোবিজ্ঞান প্রথম পত্র">মনোবিজ্ঞান প্রথম পত্র</option>
<option value="মনোবিজ্ঞান দ্বিতীয় পত্র">মনোবিজ্ঞান দ্বিতীয় পত্র</option>


<option value="ভূগোল প্রথম পত্র">ভূগোল প্রথম পত্র</option>
<option value="ভূগোল দ্বিতীয় পত্র">ভূগোল দ্বিতীয় পত্র</option>
<option value="পরিসংখ্যান প্রথম পত্র">পরিসংখ্যান প্রথম পত্র</option>
<option value="পরিসংখ্যান দ্বিতীয় পত্র">পরিসংখ্যান দ্বিতীয় পত্র</option>
<option value="অর্থনীতি প্রথম পত্র">অর্থনীতি প্রথম পত্র</option>
<option value="অর্থনীতি দ্বিতীয় পত্র">অর্থনীতি দ্বিতীয় পত্র</option>
<option value="হিসাববিজ্ঞান প্রথম পত্র">হিসাববিজ্ঞান প্রথম পত্র</option>
<option value="হিসাববিজ্ঞান দ্বিতীয় পত্র">হিসাববিজ্ঞান দ্বিতীয় পত্র</option>
<option value="অর্থায়ন প্রথম পত্র">অর্থায়ন প্রথম পত্র</option>
<option value="অর্থায়ন দ্বিতীয় পত্র">অর্থায়ন দ্বিতীয় পত্র</option>
<option value="ব্যবস্থাপনা প্রথম পত্র">ব্যবস্থাপনা প্রথম পত্র</option>
<option value="ব্যবস্থাপনা দ্বিতীয় পত্র">ব্যবস্থাপনা দ্বিতীয় পত্র</option>
<option value="বিপণন প্রথম পত্র">বিপণন প্রথম পত্র</option>
<option value="বিপণন দ্বিতীয় পত্র">বিপণন দ্বিতীয় পত্র</option>

<option value="যুক্তিবিদ্যা প্রথম পত্র">যুক্তিবিদ্যা প্রথম পত্র</option>
<option value="যুক্তিবিদ্যা দ্বিতীয় পত্র">যুক্তিবিদ্যা দ্বিতীয় পত্র</option>

<option value="ইতিহাস প্রথম পত্র">ইতিহাস প্রথম পত্র</option>
<option value="ইতিহাস দ্বিতীয় পত্র">ইতিহাস দ্বিতীয় পত্র</option>
<option value="সমাজবিজ্ঞান প্রথম পত্র">সমাজবিজ্ঞান প্রথম পত্র</option>
<option value="সমাজবিজ্ঞান দ্বিতীয় পত্র">সমাজবিজ্ঞান দ্বিতীয় পত্র</option>

<option value="পৌরনীতি প্রথম পত্র">পৌরনীতি প্রথম পত্র</option>
<option value="পৌরনীতি দ্বিতীয় পত্র">পৌরনীতি দ্বিতীয় পত্র</option>

<?php
}
?>