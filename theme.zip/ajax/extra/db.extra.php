<?php 
include '../db_back.php';
include '../../functions.php';
?>