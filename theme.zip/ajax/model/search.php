<?php 
$r = ['ActionScript', 'AppleScript', 'Asp', 'Python', 'Ruby'];

echo json_encode($r);

?>