<script type="text/javascript"
    src="<?php get_domain("/js/")?>codemirror.min.js"></script>
  <script type="text/javascript"
    src="<?php get_domain("/js/")?>xml.min.js"></script>
  <script type="text/javascript" src="editor/js/froala_editor.min.js"></script>




  <script type="text/javascript" src="editor/js/plugins/align.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/char_counter.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/code_beautifier.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/code_view.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/colors.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/draggable.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/emoticons.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/entities.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/file.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/font_size.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/font_family.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/fullscreen.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/image.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/image_manager.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/line_breaker.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/inline_style.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/link.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/lists.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/paragraph_format.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/paragraph_style.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/quick_insert.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/quote.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/table.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/save.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/url.min.js"></script>
  <script type="text/javascript" src="editor/js/plugins/video.min.js"></script>