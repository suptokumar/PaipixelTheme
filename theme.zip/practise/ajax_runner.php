<?php 
echo rand(0,1);
?>