<?php 


$a="U.B.C";

echo ucfirst($a);



 ?>