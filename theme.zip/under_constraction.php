<style>
.full-height {
    height: 2295px;
}

.flex-center {
    align-items: center;
    display: flex;
    justify-content: center;
}
</style>
<div class="flex-center position-ref full-height">
    <div class="content">
        <div style="text-align: center;">
           <h1>This page is under Constraction.</h1>
        </div>
</div>
</div>

